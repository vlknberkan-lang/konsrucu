# Rücu Takip — UYAP Senkron v1.4.0

Eski sürüm: `../uyap-eklenti-ARSIV-v0.6.7/` (geri dönüş gerekirse duruyor; endpoint bilgisi oradan taşındı).

## v1.4.0 — 🎬 Keşif Kaydı (Takip Aç Kopilotu · Faz 0)
Hedef: icra takibini **UYAP portalının kendi sihirbazı** üzerinden yarı-otomatik açmak
(e-Takip XML yolu 2026-06-30'da tamamen iptal edildi — o yola dönülmüyor). Karar: **kopilot modeli** —
eklenti doldurur, nihai Gönder'e AVUKAT basar; harç/Barokart ödemesi manuel kalır.

Faz 0 = keşif: paneldeki **🎬 Keşif Kaydı** açıkken sekmedeki TÜM ağ trafiği (tam istek gövdesi —
FormData/evrak dahil — + yanıt + SPA rota geçişleri) kaydedilir. Avukat takip açma sihirbazını
**bir kez elle** yürütür, ⏹ ile durdurunca kayıt tek `uyap-kesif-*.json` olarak iner → bu dosya
Faz 1-2'nin (program `takip-hedefler`/`takip-sonuc` uçları + eklenti doldurma motoru) girdisidir.
Sayfa yenilenirse/yeni sekme açılırsa kayıt kaldığı yerden sürer (storage yedeği birleşir).
Keşif de salt-okumadır: istek üretilmez/değiştirilmez, sadece dinlenir.
Not: sihirbaz avukat.uyap.gov.tr dışına (başka alt alan) çıkarsa content script eşleşmesi genişletilmeli.

## v1 tasarım ilkeleri
1. **Kimlik = (İcra Dairesi + Esas No) çifti.** Esas no tek başına kimlik değildir — aynı numara
   farklı dairelerde başka dosyadır. Sorgu `birimId` ile daire içinde yapılır.
2. **Bulunamayan dosya raporlanır.** Her hedef için eşleşme sonucu programa POST edilir:
   `OK | DAIRE_EKSIK | DAIRE_COZULEMEDI | BULUNAMADI | BASKA_DAIRE | COKLU_BELIRSIZ | HATA`
   → programda dosya kartında kırmızı uyarı + Bugün panosunda "UYAP'ta bulunamayan N dosya".
   BASKA_DAIRE notunda dosyanın GERÇEKTE hangi dairede bulunduğu yazar (daire kaydını düzeltmek için).
3. **Çoklu eşleşme çözümü:** aynı (daire, esas) birden çok dosya dönerse taraf sorgusuyla
   **alacaklısı tenant unvanı** (programdan gelir — Ray/Zurich hard-code YOK) olan seçilir;
   net kazanan yoksa `COKLU_BELIRSIZ` + aday listesi raporlanır.
4. **dosyaId (program kimliği)** her gönderide taşınır → programda kesin eşleşme.
5. **Masraf toplayıcı modüler:** `masrafTopla(dosyaId, rec)` iskeleti hazır — kaynak ekran
   belirlenince (Berkan gösterecek) doldurulacak; program `/api/uyap/senkron` `masraflar[]`
   alanını şimdiden kabul ediyor (dedup: `UYAPH|makbuzNo|tarih|kuruş`).
6. Salt-okuma: UYAP'a hiçbir yazma isteği gitmez. 30 dk poll (UYAP sekmesi açıkken) + panelden elle.

## Kurulum / güncelleme
Program → Chrome Eklentisi sayfasından zip indir → `chrome://extensions` → Paketlenmemiş yükle
(güncellemede: mevcut klasörün üzerine çıkarıp ↻ Yenile yeter). Ayar: panel ⚙ → program adresi + senkron anahtarı.

## Dosyalar
- `manifest.json` — MV3, yalnız avukat.uyap.gov.tr + program hostları
- `background.js` — ikon toggle · program API köprüsü (Bearer) · 30 dk alarm
- `content.js` — sorgu motoru + eşleştirme çekirdeği + evrak yükleme + mini panel

## Bilinen sınırlar (v1)
- Dava (Tüketici Mahkemesi) hedef takibi henüz taşınmadı — arşiv sürümde var, ihtiyaçta port edilir.
- Evrakın yerel diske indirilmesi kaldırıldı (program zaten saklıyor ve önizletiyor).
