/* Rücu Takip — UYAP Senkron (content script)
 * UYAP Avukat Portalı "Dosya Sorgulama" sonuç tablosunu (DevExtreme DataGrid)
 * okur. Sadece okuma yapar — hiçbir tıklama/işlem/sorgu GÖNDERMEZ ve dosya
 * detayına (safahat/evrak) GİRMEZ → harç/ücret çıkmaz.
 *
 * Tablo yapısı (gerçek DOM'dan kalibre edildi):
 *   - DevExtreme grid: başlık ayrı tabloda, veri satırları ayrı tabloda.
 *   - Veri hücreleri: <td role="gridcell" aria-colindex="N"> → kolon indeksi sabit.
 *   - Kolonlar: 1 Birim · 2 Dosya No · 3 Dosya Türü · 4 Dosya Durumu · 5 Açılış.
 *
 * 2813 dosya 10'arlı sayfalandığı için: tek tek (veya sayfa sayfa) sorgula,
 * her sonuçta "➕ Biriktir" → eklenti üst üste ekleyip hedef 6 dosyayı eşleştirir.
 */
(function () {
  "use strict";
  if (window.__rucuUyapLoaded) return;
  window.__rucuUyapLoaded = true;

  // --- Hedef dosyalar (Rucu_Takip.xlsx — icrası açılan 6 dosya) -------------
  const DEFAULT_TARGETS = [
    "2025/39428",
    "2026/4186",
    "2026/4724",
    "2026/10678",
    "2026/19449",
    "2026/32147"
  ];

  // Varsayılan kolon haritası (başlık okunamazsa) — gerçek DOM'a göre
  const DEFAULT_COLMAP = { 1: "birim", 2: "dosyaNo", 3: "tur", 4: "durum", 5: "acilis" };

  // --- Yardımcılar ----------------------------------------------------------
  const tr = (s) => (s == null ? "" : String(s)).replace(/\s+/g, " ").trim();
  const UP = (s) => tr(s).toLocaleUpperCase("tr-TR");

  const ESAS_RE = /\b((?:19|20)\d{2})\s*\/\s*(\d{1,7})\b/;
  function extractEsas(text) {
    const m = String(text == null ? "" : (typeof text === "object" ? (text.full || text.icraDosyaNo || "") : text)).match(ESAS_RE);
    return m ? `${m[1]}/${m[2]}` : "";
  }

  const COLS = {
    dosyaNo: ["DOSYA NO", "ESAS NO", "ESAS NUMARASI", "DOSYA NUMARASI", "ESAS"],
    birim: ["BİRİM", "BİRİM ADI", "İCRA DAİRESİ", "İCRA MÜDÜRLÜĞÜ", "MAHKEME", "DAİRE", "YARGI BİRİMİ"],
    durum: ["DOSYA DURUMU", "DURUM"],
    tur: ["DOSYA TÜRÜ", "TÜR", "DOSYA TİPİ"],
    acilis: ["DOSYA AÇILIŞ TARİHİ", "AÇILIŞ TARİHİ", "AÇILIŞ"],
    taraf: ["TARAF", "TARAFLAR", "BORÇLU", "DAVALI", "KARŞI TARAF"]
  };
  function matchCol(headerText) {
    const h = UP(headerText);
    if (!h) return null;
    for (const key of Object.keys(COLS)) {
      for (const syn of COLS[key]) {
        if (h === syn || h.includes(syn)) return key;
      }
    }
    return null;
  }

  const RE_KAPALI = /(KAPA|ARŞİV|ARSIV|DÜŞ|DUS|HİTAM|HITAM|ZAMANAŞIM|ZAMANASIM|FERAGAT|İNFAZEN|INFAZEN|İPTAL|IPTAL)/;
  const RE_ACIK = /(DERDEST|AÇIK|ACIK|FAAL|DEVAM|İŞLEMDE|ISLEMDE)/;
  function classifyDurum(raw) {
    const u = UP(raw);
    if (!u) return "BELİRSİZ";
    if (RE_KAPALI.test(u)) return "KAPALI";
    if (RE_ACIK.test(u)) return "AÇIK";
    return "BELİRSİZ";
  }
  // UYAP'ın sayısal dosyaDurumKod'u (0=Açık · 1=Kapalı) metinden daha güvenilir → varsa onu kullan, yoksa metne düş.
  function durumKodTahmin(kod, raw) {
    if (kod === 0 || kod === "0") return "AÇIK";
    if (kod === 1 || kod === "1") return "KAPALI";
    return classifyDurum(raw);
  }

  function collectDocs() {
    const docs = [];
    const seen = new Set();
    function walk(doc) {
      if (!doc || seen.has(doc)) return;
      seen.add(doc);
      docs.push(doc);
      let frames = [];
      try { frames = doc.querySelectorAll("iframe, frame"); } catch (e) { frames = []; }
      frames.forEach((f) => { try { if (f.contentDocument) walk(f.contentDocument); } catch (e) {} });
    }
    walk(document);
    return docs;
  }

  // --- DevExtreme grid okuma -----------------------------------------------
  function buildColMap(docs) {
    const map = {};
    docs.forEach((doc) => {
      let hs = [];
      try { hs = doc.querySelectorAll('[role="columnheader"][aria-colindex]'); } catch (e) {}
      hs.forEach((h) => {
        const ci = parseInt(h.getAttribute("aria-colindex"), 10);
        if (!ci || map[ci] !== undefined) return;
        const lbl = (h.getAttribute("aria-label") || "").replace(/^Sütun\s+/i, "") || h.textContent;
        const key = matchCol(lbl);
        if (key) map[ci] = key;
      });
    });
    return Object.keys(map).length ? map : Object.assign({}, DEFAULT_COLMAP);
  }

  function readGridRows(docs, colmap) {
    const recs = [];
    docs.forEach((doc) => {
      let rows = [];
      try { rows = doc.querySelectorAll('tr.dx-data-row, [role="row"]'); } catch (e) {}
      rows.forEach((r) => {
        const cells = r.querySelectorAll('[role="gridcell"][aria-colindex]');
        if (!cells.length) return; // başlık satırı / boş satır
        const byCi = {};
        cells.forEach((c) => {
          const ci = parseInt(c.getAttribute("aria-colindex"), 10);
          if (ci && byCi[ci] === undefined) byCi[ci] = c;
        });
        const get = (key) => {
          for (const ci in colmap) if (colmap[ci] === key && byCi[ci]) return tr(byCi[ci].textContent);
          return "";
        };
        const rowText = tr(r.textContent);
        let dosyaNo = extractEsas(get("dosyaNo")) || extractEsas(rowText);
        if (!dosyaNo) return;
        const durum = get("durum");
        recs.push({
          dosyaNo, birim: get("birim"), durum, tur: get("tur"),
          acilis: get("acilis"), taraf: get("taraf"),
          durumTahmin: classifyDurum(durum), rowText
        });
      });
    });
    return recs;
  }

  // Yedek: klasik <table> (başlık + veri aynı tabloda) için
  function readPlainTables(docs) {
    const recs = [];
    docs.forEach((doc) => {
      let tables = [];
      try { tables = doc.querySelectorAll("table"); } catch (e) {}
      tables.forEach((tbl) => {
        const trs = Array.from(tbl.querySelectorAll("tr"));
        if (trs.length < 2) return;
        let hmap = null, hidx = -1;
        for (let i = 0; i < Math.min(trs.length, 4); i++) {
          const cs = Array.from(trs[i].querySelectorAll("th,td"));
          const m = {}; let hit = 0;
          cs.forEach((c, idx) => { const k = matchCol(c.textContent); if (k && m[k] === undefined) { m[k] = idx; hit++; } });
          if (hit && (m.dosyaNo !== undefined || m.durum !== undefined)) { hmap = m; hidx = i; break; }
        }
        if (!hmap) return;
        for (let i = hidx + 1; i < trs.length; i++) {
          const cs = Array.from(trs[i].querySelectorAll("th,td"));
          if (!cs.length) continue;
          const g = (k) => (hmap[k] !== undefined && cs[hmap[k]]) ? tr(cs[hmap[k]].textContent) : "";
          const rowText = tr(trs[i].textContent);
          const dosyaNo = extractEsas(g("dosyaNo")) || extractEsas(rowText);
          if (!dosyaNo) continue;
          recs.push({ dosyaNo, birim: g("birim"), durum: g("durum"), tur: g("tur"), acilis: g("acilis"), taraf: g("taraf"), durumTahmin: classifyDurum(g("durum")), rowText });
        }
      });
    });
    return recs;
  }

  function scan() {
    const docs = collectDocs();
    const colmap = buildColMap(docs);
    let rows = readGridRows(docs, colmap);
    let mode = "devextreme";
    if (!rows.length) { rows = readPlainTables(docs); mode = "tablo"; }
    // dosyaNo bazında tekille (grid iki kez render edilebiliyor)
    const byNo = new Map();
    rows.forEach((r) => {
      const ex = byNo.get(r.dosyaNo);
      if (!ex || (!ex.durum && r.durum)) byNo.set(r.dosyaNo, r);
    });
    return { rows: Array.from(byNo.values()), rawCount: rows.length, mode, colmap };
  }

  // --- Depolama -------------------------------------------------------------
  function getTargets() {
    return new Promise((res) => chrome.storage.local.get(["targets"], (o) => {
      if (o && Array.isArray(o.targets) && o.targets.length) res(o.targets);
      else { chrome.storage.local.set({ targets: DEFAULT_TARGETS }); res(DEFAULT_TARGETS.slice()); }
    }));
  }
  function setTargets(list) { return new Promise((r) => chrome.storage.local.set({ targets: list }, r)); }
  function getAccum() { return new Promise((r) => chrome.storage.local.get(["accum"], (o) => r((o && o.accum) || []))); }
  function setAccum(arr) { return new Promise((r) => chrome.storage.local.set({ accum: arr }, r)); }

  // --- Dışa aktarma ---------------------------------------------------------
  function download(name, text, mime) {
    const blob = new Blob([text], { type: (mime || "text/plain") + ";charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }
  async function copy(text) {
    try { await navigator.clipboard.writeText(text); return true; }
    catch (e) {
      try {
        const ta = document.createElement("textarea");
        ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
        document.body.appendChild(ta); ta.focus(); ta.select();
        const ok = document.execCommand("copy"); ta.remove(); return ok;
      } catch (_) { return false; }
    }
  }
  function captureDom() {
    const docs = collectDocs();
    const cut = (s, n) => { s = s == null ? "" : String(s); return s.length > n ? s.slice(0, n) + "…" : s; };
    const attr = (el, a) => el.getAttribute(a) || "";
    function pchain(el) {
      const s = []; let p = el.parentElement, d = 0;
      while (p && d < 4) {
        const cls = tr(String(p.className || "")).split(" ").filter(Boolean).slice(0, 3).join(".");
        s.push(p.tagName.toLowerCase() + (p.id ? "#" + p.id : "") + (cls ? "." + cls : "")); p = p.parentElement; d++;
      }
      return s.join(" > ");
    }
    let out = "<!-- RÜCU UYAP FORM DOM v2 (form-aware) -->\n";
    out += `URL: ${location.href}\nTarih: ${new Date().toISOString()}\n\n`;

    out += "===== GİRİŞ KONTROLLERİ (input / select / textarea) =====\n";
    docs.forEach((doc, di) => {
      let cs = []; try { cs = doc.querySelectorAll("input, select, textarea"); } catch (e) {}
      cs.forEach((c, i) => {
        out += `[doc${di}.${i}] <${c.tagName.toLowerCase()} type="${attr(c, "type")}" id="${c.id || ""}" name="${attr(c, "name")}" class="${cut(c.className, 90)}" placeholder="${attr(c, "placeholder")}" aria-label="${attr(c, "aria-label")}" inputmode="${attr(c, "inputmode")}" role="${attr(c, "role")}" value="${cut(c.value, 30)}">\n     ↳ ${cut(pchain(c), 220)}\n`;
      });
    });

    out += "\n===== BUTON / TIKLANABİLİR =====\n";
    docs.forEach((doc, di) => {
      let bs = []; try { bs = doc.querySelectorAll('button, [role="button"], .dx-button, .btn'); } catch (e) {}
      const seen = new Set();
      bs.forEach((b) => {
        const t = tr(b.textContent), al = attr(b, "aria-label");
        const k = t + "|" + al + "|" + (b.id || ""); if (seen.has(k) || (!t && !al)) return; seen.add(k);
        out += `[doc${di}] <${b.tagName.toLowerCase()} id="${b.id || ""}" class="${cut(b.className, 90)}" aria-label="${al}"> "${cut(t, 50)}"\n`;
      });
    });

    out += "\n===== ANAHTAR / TOGGLE (Dosya Durumu) =====\n";
    docs.forEach((doc, di) => {
      let sw = []; try { sw = doc.querySelectorAll('.dx-switch, [role="switch"], [class*="switch"]'); } catch (e) {}
      sw.forEach((s) => { out += `[doc${di}] <${s.tagName.toLowerCase()} class="${cut(s.className, 90)}" aria-label="${attr(s, "aria-label")}" aria-checked="${attr(s, "aria-checked")}"> "${cut(tr(s.textContent), 40)}"\n`; });
    });

    out += "\n===== FORM KONTEYNERİ (Sorgula çevresi · outerHTML) =====\n";
    let cont = null;
    docs.forEach((doc) => {
      if (cont) return;
      let cand = []; try { cand = doc.querySelectorAll('button, [role="button"], .dx-button, span'); } catch (e) {}
      for (const b of cand) {
        if (!/sorgula/i.test(tr(b.textContent))) continue;
        let p = b;
        for (let k = 0; k < 8 && p.parentElement; k++) { p = p.parentElement; if (p.querySelector && p.querySelector("input")) { cont = p; break; } }
        if (cont) break;
      }
    });
    if (cont) { let h = cont.outerHTML; if (h.length > 90000) h = h.slice(0, 90000) + "\n...[KISALTILDI]..."; out += h + "\n"; }
    else out += "(Sorgula konteyneri bulunamadı)\n";

    out += "\n===== SONUÇ TABLOLARI =====\n";
    let n = 0;
    docs.forEach((doc, di) => {
      let els = []; try { els = doc.querySelectorAll('table, [role="grid"]'); } catch (e) {}
      els.forEach((el) => { if (n >= 6) return; n++; let h = ""; try { h = el.outerHTML; } catch (e) {} if (h.length > 20000) h = h.slice(0, 20000) + "\n...[KISALTILDI]..."; out += `\n--- grid #${n} (doc${di}) ---\n${h}\n`; });
    });

    download("uyap-form-dom.html", out, "text/html");
  }

  // --- UI -------------------------------------------------------------------
  const CSS = `
  .rucu-fab{position:fixed;right:18px;bottom:18px;z-index:2147483646;background:#0f766e;color:#fff;border:none;border-radius:999px;padding:11px 16px;font:600 13px/1 system-ui,Segoe UI,sans-serif;box-shadow:0 4px 14px rgba(0,0,0,.25);cursor:pointer}
  .rucu-fab:hover{background:#0d5f59}
  .rucu-panel{position:fixed;right:18px;bottom:64px;z-index:2147483647;width:440px;max-height:80vh;background:#fff;color:#111;border:1px solid #d4d4d8;border-radius:12px;overflow:hidden;display:none;box-shadow:0 12px 40px rgba(0,0,0,.30);font:13px/1.45 system-ui,Segoe UI,sans-serif}
  .rucu-panel.open{display:flex;flex-direction:column}
  .rucu-hd{background:#0f766e;color:#fff;padding:10px 12px;display:flex;align-items:center;justify-content:space-between}
  .rucu-x{background:transparent;border:none;color:#fff;font-size:18px;cursor:pointer;line-height:1}
  .rucu-bd{padding:10px 12px;overflow:auto}
  .rucu-row{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px}
  .rucu-btn{background:#0f766e;color:#fff;border:none;border-radius:7px;padding:7px 10px;font:600 12px system-ui;cursor:pointer}
  .rucu-btn.sec{background:#e4e4e7;color:#18181b}
  .rucu-btn.warn{background:#b91c1c}
  .rucu-btn:hover{filter:brightness(.95)}
  .rucu-sum{background:#f4f4f5;border:1px solid #e4e4e7;border-radius:8px;padding:8px 10px;margin-bottom:10px;font-size:12px}
  .rucu-tbl{width:100%;border-collapse:collapse;font-size:12px}
  .rucu-tbl th,.rucu-tbl td{border-bottom:1px solid #eee;padding:5px 6px;text-align:left;vertical-align:top}
  .rucu-tbl th{background:#fafafa;font-weight:700}
  .rucu-badge{display:inline-block;padding:1px 7px;border-radius:999px;font-size:11px;font-weight:700}
  .b-acik{background:#dcfce7;color:#166534}
  .b-kapali{background:#fee2e2;color:#991b1b}
  .b-belirsiz{background:#fef9c3;color:#854d0e}
  .b-yok{background:#e4e4e7;color:#3f3f46}
  .rucu-mut{color:#71717a;font-size:11px}
  .rucu-ta{width:100%;height:90px;font:12px ui-monospace,Consolas,monospace;border:1px solid #d4d4d8;border-radius:7px;padding:6px;box-sizing:border-box}
  .rucu-sec-t{font-weight:700;margin:12px 0 6px;font-size:12px;color:#3f3f46}
  details>summary{cursor:pointer}
  `;
  function injectCss() {
    if (document.getElementById("rucu-css")) return;
    const s = document.createElement("style");
    s.id = "rucu-css"; s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }

  let panel, bodyEl, lastReport = null, running = false;

  function buildUi() {
    injectCss();
    const fab = document.createElement("button");
    fab.className = "rucu-fab"; fab.textContent = "⚖ Rücu Tara"; fab.title = "Rücu Takip — UYAP";
    fab.addEventListener("click", togglePanel);
    document.body.appendChild(fab);

    panel = document.createElement("div");
    panel.className = "rucu-panel";
    panel.innerHTML = `
      <div class="rucu-hd"><b>⚖ Rücu Takip · UYAP</b><button class="rucu-x" title="Kapat">×</button></div>
      <div class="rucu-bd">
        <div class="rucu-row">
          <button class="rucu-btn" data-act="auto" style="flex:1;background:#1d4ed8">▶ İcra Sorgula (API)</button>
        </div>
        <div class="rucu-row" style="align-items:center">
          <label style="display:flex;align-items:center;gap:6px;font-size:12px">📥 Evrak PDF:
            <select id="rucu-dlmode" style="font-size:12px;padding:2px 4px;border-radius:5px">
              <option value="none" selected>indirme (sadece liste)</option>
              <option value="key">önemli evraklar</option>
              <option value="all">tüm evraklar</option>
            </select>
          </label>
        </div>
        <div class="rucu-row">
          <button class="rucu-btn" data-act="dava" style="flex:1;background:#0e7490">▶ Dava Sorgula (Tüketici)</button>
          <button class="rucu-btn sec" data-act="davahedef">🎯 Dava Hedef</button>
        </div>
        <div class="rucu-row">
          <button class="rucu-btn" data-act="biriktir">➕ Tara &amp; Biriktir</button>
          <button class="rucu-btn sec" data-act="scan">🔍 Hızlı Tara</button>
          <button class="rucu-btn warn" data-act="sifirla">🗑 Sıfırla</button>
        </div>
        <div class="rucu-row">
          <button class="rucu-btn" data-act="ozet" style="background:#7c3aed">📄 Özet</button>
          <button class="rucu-btn sec" data-act="json">⬇ JSON</button>
          <button class="rucu-btn sec" data-act="copy">📋 Kopyala</button>
          <button class="rucu-btn sec" data-act="dom">🧪 DOM Yakala</button>
          <button class="rucu-btn sec" data-act="hedef">🎯 Hedef</button>
          <button class="rucu-btn sec" data-act="diag" style="background:#fde68a;color:#000">🔧 Tanı</button>
          <button class="rucu-btn sec" data-act="evrakraw" style="background:#fde68a;color:#000">🔎 Ham Evrak</button>
          <button class="rucu-btn sec" data-act="captured" style="background:#fde68a;color:#000">🕸 Ağ</button>
          <button class="rucu-btn" data-act="kesif" style="background:#7c3aed">🔭 Keşif (Dava)</button>
        </div>
        <div class="rucu-row" style="border-top:1px dashed #cbd5e1;padding-top:6px;margin-top:2px">
          <button class="rucu-btn" data-act="progsenk" style="flex:1;background:#0f766e">⇅ Program'a Senkronla</button>
          <button class="rucu-btn sec" data-act="proghedef">🎯 Programdan Hedef</button>
          <button class="rucu-btn sec" data-act="progset">⚙ Program Ayarı</button>
        </div>
        <div class="rucu-out"><div class="rucu-mut">UYAP Avukat Portalı açıkken <b>▶ Oto Sorgula</b>'ya bas — 6 rücu dosyasının durumu + asıl alacak, işlemiş faiz, tahsilat, bakiye ve evrak/safahatını çeker. Form doldurmana gerek yok.</div></div>
      </div>`;
    document.body.appendChild(panel);
    bodyEl = panel.querySelector(".rucu-out");
    panel.querySelector(".rucu-x").addEventListener("click", togglePanel);
    panel.querySelectorAll("[data-act]").forEach((b) => b.addEventListener("click", () => onAct(b.dataset.act)));
    // Önceki biriktirmeyi göster
    getAccum().then((a) => { if (a.length) renderReport(a, { mode: "biriktir", restored: true }); });
  }

  function togglePanel() { if (!panel) buildUi(); panel.classList.toggle("open"); }

  async function onAct(act) {
    if (act === "scan") { const r = scan(); return renderReport(r.rows, { mode: "hizli", scanInfo: r }); }
    if (act === "auto") return doAuto();
    if (act === "dava") return doDavaAuto();
    if (act === "davahedef") return showDavaTargets();
    if (act === "ozet") return doOzet();
    if (act === "diag") return doDiag();
    if (act === "evrakraw") return doEvrakRaw();
    if (act === "captured") return doCaptured();
    if (act === "kesif") return doKesifDava();
    if (act === "biriktir") return doBiriktir();
    if (act === "sifirla") { await setAccum([]); lastReport = null; bodyEl.innerHTML = `<div class="rucu-mut">Biriktirme sıfırlandı.</div>`; return; }
    if (act === "dom") return captureDom();
    if (act === "progset") return progAyar();
    if (act === "proghedef") return progHedef();
    if (act === "progsenk") return progSenk();
    if (act === "hedef") return showTargets();
    if (act === "json") {
      if (!lastReport) { const r = scan(); await renderReport(r.rows, { mode: "hizli", scanInfo: r }); }
      return download("uyap-rucu-durum.json", JSON.stringify(lastReport, null, 2), "application/json");
    }
    if (act === "copy") {
      if (!lastReport) { const r = scan(); await renderReport(r.rows, { mode: "hizli", scanInfo: r }); }
      const ok = await copy(JSON.stringify(lastReport, null, 2));
      flash(ok ? "Panoya kopyalandı." : "Kopyalama başarısız.");
    }
  }

  function flash(msg) {
    const d = document.createElement("div");
    d.textContent = msg;
    d.style.cssText = "margin:6px 0;padding:6px 8px;background:#ecfeff;border:1px solid #a5f3fc;border-radius:6px;font-size:12px";
    bodyEl.prepend(d); setTimeout(() => d.remove(), 2500);
  }

  async function doBiriktir() {
    const r = scan();
    const prev = await getAccum();
    const map = new Map(prev.map((x) => [x.dosyaNo, x]));
    let added = 0;
    r.rows.forEach((row) => { if (!map.has(row.dosyaNo)) added++; map.set(row.dosyaNo, Object.assign({}, map.get(row.dosyaNo), row)); });
    const merged = Array.from(map.values());
    await setAccum(merged);
    await renderReport(merged, { mode: "biriktir", added, justScanned: r.rows.length });
    if (!r.rows.length) flash("Bu sayfada dosya satırı okunamadı. Önce 'Sorgula' ile sonuç çıkar, sonra Biriktir.");
  }

  // ───────── Rücu Takip programı senkronu (background üzerinden, Bearer = anahtar) ─────────
  function sendBg(msg) {
    return new Promise((res) => {
      try { chrome.runtime.sendMessage(msg, (r) => res(r || { ok: false, error: chrome.runtime.lastError ? chrome.runtime.lastError.message : "yanıt yok" })); }
      catch (e) { res({ ok: false, error: e.message }); }
    });
  }

  async function progAyar() {
    const cur = await new Promise((r) => chrome.storage.local.get(["programBase", "senkronToken"], (o) => r(o || {})));
    const base = window.prompt("Program adresi:", cur.programBase || "https://konsrucu.vercel.app");
    if (base === null) return;
    const token = window.prompt("Senkron anahtarı (Şirket Bilgileri → UYAP Eklenti Senkron Anahtarı):", cur.senkronToken || "");
    if (token === null) return;
    await new Promise((r) => chrome.storage.local.set({ programBase: base.trim().replace(/\/+$/, ""), senkronToken: token.trim() }, r));
    flash("Program ayarı kaydedildi.");
  }

  async function progHedef() {
    flash("Program hedefleri çekiliyor…");
    const r = await sendBg({ type: "RUCU_HEDEFLER" });
    if (!r.ok || !r.data || !r.data.ok) { flash("Hedef alınamadı: " + (r.error || (r.data && r.data.error) || ("HTTP " + r.status))); return; }
    const hedefler = (r.data.hedefler || []).filter((h) => h.icraDosyaNo);
    if (!hedefler.length) { flash("Programda takibi açık (icra no'lu) dosya yok."); return; }
    hedefler.forEach((h) => { if (h.daire) DAIRE_MAP[String(h.icraDosyaNo)] = h.daire; }); // program dairesini eşleme tablosuna ekle
    await setTargets(hedefler.map((h) => String(h.icraDosyaNo))); // hedefler STRING (esas no) olarak kaydedilir
    flash(hedefler.length + " hedef programdan alındı. ▶ İcra Sorgula ile tara.");
  }

  // rec'ten takip olayları türet (tebliğ/itiraz/haciz/tahsilat) — program TakipOlayi'na yazar, (tip+tarih) ile dedup.
  function olaylardanRec(rec) {
    const ol = [];
    const ekle = (tip, tarih, aciklama) => { if (tip && tarih) ol.push({ tip, tarih, aciklama: String(aciklama || "").slice(0, 200) }); };
    if (rec.tebligTarihi) ekle("TEBLIG", rec.tebligTarihi, "Tebliğ (UYAP)");
    for (const ev of (rec.evrak || [])) {
      const t = String(ev.tur || ev.aciklama || "").toLowerCase();
      let tip = null;
      if (/itiraz/.test(t)) tip = "ITIRAZ";
      else if (/haciz/.test(t)) tip = "HACIZ";
      else if (/kesinleş|kesinles/.test(t)) tip = "KESINLESTI";
      else if (/tahsil|reddiyat|makbuz|ödeme|odeme/.test(t)) tip = "TAHSILAT";
      else if (/tebli|mazbata/.test(t)) tip = "TEBLIG";
      if (tip) ekle(tip, ev.tarih || ev.tebligTarihi, ev.tur || ev.aciklama);
    }
    return ol;
  }

  function senkronGovde(rec) {
    return {
      icraDosyaNo: rec.dosyaNo,
      durum: rec.durumTahmin || rec.durum || null,
      olaylar: olaylardanRec(rec),
      hesap: {
        durumMetni: rec.durum || null, birim: rec.birim || null,
        toplamAlacak: rec.toplamAlacak != null ? rec.toplamAlacak : null,
        asilAlacak: rec.asilAlacak != null ? rec.asilAlacak : null,
        islemisFaiz: rec.islemisFaiz != null ? rec.islemisFaiz : null,
        tahsilat: rec.tahsilat != null ? rec.tahsilat : null,
        bakiye: rec.bakiye != null ? rec.bakiye : null,
        vekalet: rec.vekalet != null ? rec.vekalet : null,
        sonEvrakTarihi: rec.sonEvrakTarihi || null, evrakSayisi: (rec.evrak && rec.evrak.length) || 0,
      },
    };
  }

  async function pushAccum() {
    const accum = await getAccum();
    const list = accum.filter((r) => r && r.dosyaNo && !r.belirsiz);
    let ok = 0, hata = 0;
    for (const rec of list) {
      const r = await sendBg({ type: "RUCU_SENKRON", body: senkronGovde(rec) });
      if (r.ok && r.data && r.data.ok) ok++; else hata++;
    }
    return { ok, hata, toplam: list.length };
  }

  // PDF'i base64 olarak çek (program'a yüklemek için). ~3.2MB üstünü atla. %PDF imzası yoksa reddet (HTML/oturum hatası).
  async function fetchB64(url) {
    try {
      const resp = await fetch(url, { credentials: "include" });
      if (!resp.ok) { console.warn("[rucu] PDF HTTP " + resp.status + " — " + url); return null; }
      const ct = (resp.headers.get("content-type") || "").toLowerCase();
      const buf = await resp.arrayBuffer();
      if (!buf.byteLength) { console.warn("[rucu] PDF boş yanıt — " + url); return null; }
      if (buf.byteLength > 3200000) { console.warn("[rucu] PDF çok büyük (" + buf.byteLength + " B) atlandı"); return null; }
      const bytes = new Uint8Array(buf);
      const sig = String.fromCharCode(bytes[0] || 0, bytes[1] || 0, bytes[2] || 0, bytes[3] || 0);
      if (sig !== "%PDF" && !/pdf|octet-stream/.test(ct)) { console.warn("[rucu] PDF değil (content-type: " + ct + ", baş: '" + sig + "') — " + url); return null; }
      let bin = "";
      for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
      return btoa(bin);
    } catch (e) { console.warn("[rucu] PDF fetch hata: " + (e && e.message) + " — " + url); return null; }
  }

  // Bir dosyanın YENİ evraklarını program'a yükle (base64). Yerel (gonderilenEvrak) + program (kaynakRef) dedup. Teşhis loglu.
  async function pushEvraklar(rec) {
    if (!rec || !rec.dosyaId) { console.warn("[rucu] evrak atlandı: UYAP dosyaId yok — " + (rec && rec.dosyaNo)); return 0; }
    if (!Array.isArray(rec.evrak) || !rec.evrak.length) { console.warn("[rucu] evrak listesi boş — " + rec.dosyaNo); return 0; }
    const cfg = await new Promise((r) => chrome.storage.local.get(["senkronToken"], (o) => r(o || {})));
    if (!cfg.senkronToken) { console.warn("[rucu] program anahtarı yok → evrak yüklenmedi"); return 0; }
    const gond = await new Promise((r) => chrome.storage.local.get(["gonderilenEvrak"], (o) => r((o && o.gonderilenEvrak) || {})));
    const did = String(rec.dosyaId).replace(/"/g, "").trim(); // UYAP id'leri tırnaklı gelebilir → URL/anahtar bozulmasın
    let n = 0, denendi = 0, fetchFail = 0, upFail = 0;
    for (const ev of rec.evrak) {
      if (!ev.evrakId) continue;
      const eid = String(ev.evrakId).replace(/"/g, "").trim();
      const key = rec.dosyaNo + ":" + eid;
      if (gond[key]) continue;
      denendi++;
      let b64 = null;
      const eps = (_pdfEp ? [_pdfEp].concat(PDF_ENDPOINTS.filter((e) => e !== _pdfEp)) : PDF_ENDPOINTS);
      for (const ep of eps) {
        const url = location.origin + ep + "?dosyaId=" + encodeURIComponent(did) + "&evrakId=" + encodeURIComponent(eid);
        b64 = await fetchB64(url);
        if (b64) { _pdfEp = ep; break; }
      }
      if (!b64) { fetchFail++; continue; }
      const ad = ((ev.tur || ev.aciklama || "evrak") + " " + (ev.tarih || "")).trim().slice(0, 120) + ".pdf";
      const r = await sendBg({ type: "RUCU_EVRAK", body: { icraDosyaNo: rec.dosyaNo, uyapEvrakId: eid, dosyaAdi: ad, tur: ev.tur || "", contentBase64: b64, mime: "application/pdf" } });
      if (r.ok && r.data && r.data.ok) { gond[key] = true; n++; }
      else { upFail++; console.warn("[rucu] evrak upload reddedildi: " + rec.dosyaNo + "/" + eid + " status=" + (r && r.status) + " " + (r && (r.error || (r.data && (r.data.error || r.data.sebep)) || ""))); }
      await sleep(400);
    }
    await new Promise((r) => chrome.storage.local.set({ gonderilenEvrak: gond }, r));
    console.log("[rucu] evrak " + rec.dosyaNo + ": " + n + " yüklendi / " + denendi + " denendi (fetchFail " + fetchFail + ", upFail " + upFail + ")");
    return n;
  }

  async function progSenk() {
    const accum = await getAccum();
    if (!accum.length) { flash("Önce ▶ İcra Sorgula ile dosyaları tara."); return; }
    flash("Programa yazılıyor…");
    const s = await pushAccum();
    let ev = 0;
    for (const rec of accum) { if (rec && rec.dosyaNo && !rec.belirsiz) ev += await pushEvraklar(rec); }
    flash("Program senkron: " + s.ok + "/" + s.toplam + " dosya · " + ev + " yeni evrak" + (s.hata ? (" · " + s.hata + " hata (anahtar/HTTP?)") : ""));
  }

  // OTOMATİK senkron: hedef çek → UYAP tara → finansal+olay+evrak gönder. Panel görünmese de çalışır.
  let _otoCalisiyor = false;
  async function otoSenkron() {
    if (_otoCalisiyor) return; _otoCalisiyor = true;
    try {
      if (!panel) buildUi(); // bodyEl olsun (görünür olması şart değil)
      const r = await sendBg({ type: "RUCU_HEDEFLER" });
      if (!r.ok || !r.data || !r.data.ok) return;
      const hedefler = (r.data.hedefler || []).filter((h) => h.icraDosyaNo);
      if (!hedefler.length) return;
      hedefler.forEach((h) => { if (h.daire) DAIRE_MAP[String(h.icraDosyaNo)] = h.daire; });
      await setTargets(hedefler.map((h) => String(h.icraDosyaNo)));
      await doAuto();
      await pushAccum();
      const accum = await getAccum();
      for (const rec of accum) { if (rec && rec.dosyaNo && !rec.belirsiz) await pushEvraklar(rec); }
      await new Promise((r2) => chrome.storage.local.set({ sonOtoSync: Date.now() }, r2));
    } catch (e) { /* sessiz */ } finally { _otoCalisiyor = false; }
  }

  // --- Otomatik sorgu motoru ------------------------------------------------
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // Hedef esas no → icra dairesi (Rucu_Takip.xlsx). birimId çözümü için.
  const DAIRE_MAP = {
    "2026/32147": "Gaziosmanpaşa İcra Dairesi",
    "2026/10678": "İstanbul Anadolu 10. İcra Dairesi",
    "2026/4186": "İzmir 3. İcra Dairesi",
    "2026/19449": "Balıkesir İcra Dairesi",
    "2026/4724": "İstanbul Anadolu 11. İcra Dairesi",
    "2025/39428": "İstanbul 23. İcra Dairesi"
  };

  // UYAP iç API'sine oturum çereziyle çağrı (eski eklentiden kanıtlanmış yöntem)
  async function apiPost(path, body) {
    const resp = await fetch(path, {
      method: "POST", credentials: "include",
      headers: { "Content-Type": "application/json;charset=UTF-8", "X-Requested-With": "XMLHttpRequest" },
      body: JSON.stringify(body)
    });
    if (!resp.ok) throw new Error(path.replace(/^\//, "").replace(".ajx", "") + " HTTP " + resp.status);
    const txt = await resp.text();
    try { return JSON.parse(txt); } catch (e) { throw new Error("yanıt JSON değil: " + txt.slice(0, 50)); }
  }

  // İcra Daireleri listesi (yargıTürü=İcra(2), yargıBirimi=İcra Dairesi(1101))
  async function apiMahkemeler() {
    const out = [];
    for (const kapali of [false, true]) {
      try {
        const j = await apiPost("/avukat_mahkemeleri_sorgula.ajx", { yargiTuru: "2", yargiBirimi: "1101", dosyaKapaliMi: kapali });
        if (Array.isArray(j)) out.push(...j);
      } catch (e) { /* biri patlarsa diğeri kalsın */ }
    }
    return out;
  }

  // DAVA KEŞFİ — herhangi bir yargıTürü/yargıBirimi ile birim listesi çek (ham)
  async function apiMahkemelerRaw(yargiTuru, yargiBirimi, kapali) {
    return apiPost("/avukat_mahkemeleri_sorgula.ajx", {
      yargiTuru: String(yargiTuru), yargiBirimi: String(yargiBirimi), dosyaKapaliMi: !!kapali
    });
  }

  function findBirimId(daireAdi, list) {
    if (!Array.isArray(list) || !daireAdi) return null;
    const norm = (s) => (s || "").toLocaleLowerCase("tr").replace(/\s+/g, " ").trim();
    const hedef = norm(daireAdi);
    const adOf = (m) => norm(m.birimAdi || m.birimAd || m.ad || "");
    const idOf = (m) => m.birimId || m.id || m.birim_id || null;
    for (const m of list) if (adOf(m) === hedef) return idOf(m);
    for (const m of list) { const a = adOf(m); if (a && (a.includes(hedef) || hedef.includes(a))) return idOf(m); }
    const num = daireAdi.match(/(\d+)\.\s*İcra/i);
    if (num) for (const m of list) { const a = m.birimAdi || ""; if (a.includes(num[1] + ".") && a.toLocaleLowerCase("tr").includes("icra")) return idOf(m); }
    return null;
  }

  function pickDurum(item) {
    if (!item || typeof item !== "object") return "";
    for (const k of Object.keys(item)) {
      if (/durum/i.test(k)) { const v = item[k]; if (typeof v === "string" && v.trim()) return v.trim(); }
    }
    return "";
  }

  // dosyaDurumKod: 0=Açık · 1=Kapalı · 2=Tümü → 2 hepsini getirir.
  // AYNI esas no birden fazla DAİREde olabilir → TÜM adayları döndür.
  async function apiSearchAll(yil, sira, birimId, birimTuru2) {
    const full = `${yil}/${sira}`;
    const seen = new Map();
    for (const durumKod of [2, 0, 1]) {
      const body = { dosyaDurumKod: durumKod, pageSize: 100, pageNumber: 1, dosyaYil: parseInt(yil, 10), dosyaSira: parseInt(sira, 10), birimTuru2: birimTuru2 || "1101" };
      if (birimId) body.birimId = String(birimId);
      let json;
      try { json = await apiPost("/search_phrase_detayli.ajx", body); } catch (e) { continue; }
      const items = Array.isArray(json) ? (Array.isArray(json[0]) ? json[0] : json) : [];
      items.forEach((x) => {
        if (!x || !x.dosyaId) return;
        const esas = extractEsas(x.dosyaNo || `${x.dosyaYil}/${x.dosyaSiraNo || x.dosyaSira || ""}`);
        if (esas && esas !== full) return; // sadece hedef numara
        const durum = x.dosyaDurum || pickDurum(x);
        if (!seen.has(x.dosyaId)) seen.set(x.dosyaId, {
          dosyaId: x.dosyaId, dosyaNo: full, durum, durumKod: x.dosyaDurumKod,
          birimAdi: x.birimAdi || "", birimId: x.birimId || "", acilis: detectDate(x.dosyaAcilisTarihi)
        });
        else if (!seen.get(x.dosyaId).durum && durum) seen.get(x.dosyaId).durum = durum;
      });
      await sleep(250); // 0+1+2 HEPSİNİ birleştir — açık dosya bazen yalnız durumKod=0'da gelir; break YOK
    }
    return Array.from(seen.values());
  }

  // Geriye dönük: tek aday isteyen yerler (doEvrakRaw) için ilkini ver
  async function apiSearchDosyaId(yil, sira, birimId) {
    const c = await apiSearchAll(yil, sira, birimId);
    return c.length ? c[0] : null;
  }

  // Bu dosyada RAY SİGORTA ALACAKLI mı? (taraf bilgisinden — disambiguation)
  const RAY_RE = /ray\s*si?gorta/i;
  async function rayRol(dosyaId) {
    try {
      const j = await apiPost("/dosya_taraf_bilgileri_brd.ajx", { dosyaId });
      const arr = Array.isArray(j) ? j : (j.taraflar || j.list || j.data || []);
      const taraflar = arr.map((t) => ({ ad: t.adi || t.ad || t.adSoyad || "", rol: t.rol || t.tarafTuru || t.sifat || "" }));
      return {
        alacakliRay: taraflar.some((t) => /alacakl/i.test(t.rol) && RAY_RE.test(t.ad)),
        borcluRay: taraflar.some((t) => /bor[çc]lu/i.test(t.rol) && RAY_RE.test(t.ad)),
        davaciRay: taraflar.some((t) => /davac/i.test(t.rol) && RAY_RE.test(t.ad)),
        davaliRay: taraflar.some((t) => /daval/i.test(t.rol) && RAY_RE.test(t.ad)),
        tarafRay: taraflar.some((t) => RAY_RE.test(t.ad)),
        taraflar
      };
    } catch (e) { return { alacakliRay: false, borcluRay: false, davaciRay: false, davaliRay: false, tarafRay: false, taraflar: [], hata: e.message }; }
  }

  // Daire adı eşleştirme ("Genel" ekini + şehir/numarayı tolere et)
  function daireMatch(birimAdi, daire) {
    const norm = (s) => (s || "").toLocaleLowerCase("tr").replace(/genel\s+/g, "").replace(/\s+/g, " ").trim();
    const a = norm(birimAdi), b = norm(daire);
    if (!a || !b) return false;
    if (a === b || a.includes(b) || b.includes(a)) return true;
    const numA = (a.match(/(\d+)\.\s*icra/) || [])[1];
    const numB = (b.match(/(\d+)\.\s*icra/) || [])[1];
    if (numA && numB && numA === numB && a.split(" ")[0] === b.split(" ")[0]) return true;
    return false;
  }

  // Klasör adı için kısa daire/mahkeme (… İcra Dairesi / … Mahkemesi ekini at)
  function kisaDaire(birimAdi) {
    return safeName(String(birimAdi || "").replace(/genel\s+icra dairesi/i, "").replace(/icra dairesi/i, "").replace(/mahkemesi/i, "").replace(/\s+/g, " ").trim());
  }

  // Genel birim adı eşleştirme (icra + tüketici; "N. <birim>" şehir+numara)
  function birimMatch(birimAdi, hedef) {
    const norm = (s) => (s || "").toLocaleLowerCase("tr").replace(/genel\s+/g, "").replace(/\s+/g, " ").trim();
    const a = norm(birimAdi), b = norm(hedef);
    if (!a || !b) return false;
    if (a === b || a.includes(b) || b.includes(a)) return true;
    const numOf = (s) => (s.match(/(\d+)\./) || [])[1];
    const na = numOf(a), nb = numOf(b);
    if (na && nb && na === nb && a.split(" ")[0] === b.split(" ")[0]) return true;
    return false;
  }
  function findBirimIdByName(ad, list) {
    if (!Array.isArray(list) || !ad) return null;
    const idOf = (m) => m.birimId || m.id || m.birim_id || null;
    for (const m of list) if (birimMatch(m.birimAdi || m.birimAd || m.ad, ad)) return idOf(m);
    return null;
  }

  async function apiAyrintiDurum(dosyaId) {
    const json = await apiPost("/dosyaAyrintiBilgileri_brd.ajx", { dosyaId });
    return json.dosyaDurumu || json.dosyaDurum || pickDurum(json) || "";
  }

  // ====== TAM VERİ ÇEKME (eski Ray Sigorta eklentisinden taşındı) ==========
  function fmtTL(n) { try { return Number(n).toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " TL"; } catch (e) { return String(n); } }

  function detectDate(val) {
    if (val == null || val === "" || val === 0) return "";
    if (typeof val === "object") {
      if (val.date && typeof val.date === "object" && val.date.year) {
        return `${val.date.year}-${String(val.date.month || 1).padStart(2, "0")}-${String(val.date.day || 1).padStart(2, "0")}`;
      }
      if (typeof val.time === "number") { const d = new Date(val.time); if (!isNaN(d.getTime()) && d.getFullYear() > 2000 && d.getFullYear() < 2100) return d.toISOString().slice(0, 10); }
      return "";
    }
    if (typeof val === "number") { if (val > 978307200000 && val < 4102444800000) { const d = new Date(val); if (!isNaN(d.getTime())) return d.toISOString().slice(0, 10); } return ""; }
    const s = String(val).trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
    const m = s.match(/^(\d{1,2})[.\/](\d{1,2})[.\/](\d{4})/);
    if (m) return `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
    return "";
  }

  // dosyaAyrintiBilgileri_brd.ajx → finansal özet + durum
  async function apiAyrinti(dosyaId, rec) {
    try {
      const j = await apiPost("/dosyaAyrintiBilgileri_brd.ajx", { dosyaId });
      if (!rec.durum && (j.dosyaDurumu || j.dosyaDurum)) rec.durum = j.dosyaDurumu || j.dosyaDurum;
      if (!rec.birim && j.birimAdi) rec.birim = j.birimAdi;
      if (j.alacakKalemToplamTutar != null) rec.toplamAlacak = j.alacakKalemToplamTutar;
      if (j.alacakKalemFaizTutar != null) rec.islemisFaiz = j.alacakKalemFaizTutar;
      if (j.tahsilHarci != null) rec.tahsilHarci = j.tahsilHarci;
      if (j.takipSonrasiMasraf != null) rec.masraf = j.takipSonrasiMasraf;
      if (j.vekaletUcreti != null) rec.vekalet = j.vekaletUcreti;
      if (j.yapilmisBorcTahsilati != null) rec.tahsilat = j.yapilmisBorcTahsilati;
      if (rec.toplamAlacak != null && rec.tahsilat != null) rec.bakiye = rec.toplamAlacak - rec.tahsilat;
    } catch (e) { rec._ayrintiHata = e.message; }
  }

  // dosya_hesap_bilgileri.ajx → hesap kalemleri (kesinleşen, faiz, vekalet, masraf, harç, bakiye)
  async function apiHesap(dosyaId, rec) {
    try {
      const j = await apiPost("/dosya_hesap_bilgileri.ajx", { dosyaId });
      const items = Array.isArray(j) ? j : [];
      rec.kalemler = rec.kalemler || [];
      const MAP = {
        "Takipte Kesinlesen Miktar": "asilAlacak", "Toplam Faiz Miktari": "islemisFaiz",
        "Vekalet Ücreti": "vekalet", "Vekalet Ucreti": "vekalet", "Masraf Miktari": "masraf",
        "Tahsil Harcı": "tahsilHarci", "Tahsil Harci": "tahsilHarci", "Toplam Alacak": "toplamAlacak",
        "Yatan Para": "tahsilat", "Bakiye Borç Miktari": "bakiye", "Bakiye Borc Miktari": "bakiye"
      };
      for (const it of items) {
        if (!it || typeof it !== "object") continue;
        const ad = it.textAlan || it.kalemAdi || it.aciklama || it.adi || "";
        const tutar = (it.degerAlan != null ? it.degerAlan : (it.tutar != null ? it.tutar : it.miktar));
        if (ad && tutar != null) {
          rec.kalemler.push({ ad: String(ad), tutar: Number(tutar) });
          const f = MAP[ad]; if (f && rec[f] == null) rec[f] = Number(tutar);
        }
      }
      if (rec.bakiye == null && rec.toplamAlacak != null && rec.tahsilat != null) rec.bakiye = rec.toplamAlacak - rec.tahsilat;
    } catch (e) { rec._hesapHata = e.message; }
  }

  // dosya_taraf_bilgileri_brd.ajx → borçlu/alacaklı/taraflar
  async function apiTaraf(dosyaId, rec) {
    try {
      const j = await apiPost("/dosya_taraf_bilgileri_brd.ajx", { dosyaId });
      const arr = Array.isArray(j) ? j : (j.taraflar || j.list || j.data || []);
      rec.taraflar = arr.map((t) => ({ ad: t.adi || t.ad || t.adSoyad || "", rol: t.rol || t.tarafTuru || t.sifat || "", tip: t.kisiKurum || "", tckn: t.tcKimlikNo || t.tckn || "", vekil: t.vekil || "" }));
      const borclu = rec.taraflar.filter((t) => /bor[çc]lu/i.test(t.rol)).map((t) => t.ad).filter(Boolean);
      if (borclu.length) rec.borclu = borclu.join(", ");
    } catch (e) { rec._tarafHata = e.message; }
  }

  // Evrak yanıtından ham kayıt dizisini çıkar (tüm UYAP formatları)
  function evrakItems(json) {
    let items = [];
    if (Array.isArray(json)) items = Array.isArray(json[0]) ? json[0] : json;
    else if (json && typeof json === "object") {
      items = json.evraklar || json.list || json.data || json.evrakListesi || json.content || json.rows || [];
      if ((!items || !items.length) && json.tumEvraklar && typeof json.tumEvraklar === "object") items = Object.values(json.tumEvraklar).flat();
    }
    return Array.isArray(items) ? items : [];
  }

  function parseEvrak(json) {
    const items = evrakItems(json);
    if (!items.length) return [];
    const k0 = Object.keys(items[0] || {});
    if (!k0.some((k) => /evrak|tarih|teblig|belge|konu|aciklama/i.test(k))) return [];
    return items.map((it) => {
      if (!it || typeof it !== "object") return null;
      const keys = Object.keys(it);
      let tarih = "";
      for (const c of [it.evrakTarihi, it.tarih, it.onaylandigiTarih, it.sistemeGonderildigiTarih, it.evrakGeldigiTarih, it.kayitTarihi, it.islemTarihi]) { const d = detectDate(c); if (d) { tarih = d; break; } }
      if (!tarih) for (const kk of keys) { if (/tebli/i.test(kk)) continue; const d = detectDate(it[kk]); if (d) { tarih = d; break; } }
      let teblig = ""; for (const c of [it.tebligTarihi, it.tebligatTarihi]) { const d = detectDate(c); if (d) { teblig = d; break; } }
      const tur = it.evrakTuru || it.evrakTuruAdi || it.tur || it.belgeTuru || "";
      const aciklama = it.aciklama || it.konu || it.evrakAdi || it.adi || it.baslik || "";
      const evrakId = it.evrakId || it.id || it.evrak_id || it.evrakID || it.siraNo || it.siraNo || "";
      return { evrakId, tarih, tur: String(tur), aciklama: String(aciklama), tebligTarihi: teblig };
    }).filter(Boolean);
  }

  // Rücu için kritik evrak türleri ("önemli evraklar" modu)
  const ONEMLI_EVRAK_RE = /(ödeme emri|odeme emri|tebli|mazbata|haciz|ekspertiz|kıymet|kiymet|satış|satis|itiraz|kesinleş|kesinles|karar|müzekkere|muzekkere|dekont|makbuz|tahsil|temlik|rücu|rucu|talep)/i;

  // ====== EVRAK PDF İNDİRME (İndirilenler/rucu-evrak/<dosya>/...) ===========
  const PDF_ENDPOINTS = [
    "/main/icra/modules/evrak/view_document_brd.uyap",
    "/main/icra/modules/evrak/download_document_brd.uyap"
  ];
  let _pdfEp = null;
  function dlViaBg(url, filename) {
    return new Promise((res) => {
      try { chrome.runtime.sendMessage({ type: "RUCU_DOWNLOAD", url, filename }, (r) => res(!!(r && r.ok))); }
      catch (e) { res(false); }
    });
  }
  function safeName(s) { return String(s || "").replace(/[\\/:*?"<>|]/g, "-").replace(/\s+/g, " ").trim().slice(0, 50); }

  async function downloadEvraklar(dosyaNo, dosyaId, evrakList, epList) {
    if (!dosyaId || !Array.isArray(evrakList) || !evrakList.length) return { ok: 0, total: 0 };
    const klasor = safeName(dosyaNo);
    const base = (epList && epList.length) ? epList : PDF_ENDPOINTS;
    const eps = (_pdfEp && base.indexOf(_pdfEp) >= 0) ? [_pdfEp].concat(base.filter((e) => e !== _pdfEp)) : base.slice();
    let ok = 0, n = 0;
    for (const ev of evrakList) {
      if (!ev.evrakId) continue;
      n++;
      const fname = `rucu-evrak/${klasor}/${String(n).padStart(2, "0")}_${safeName(ev.tur || "evrak")}_${ev.tarih || ""}.pdf`;
      for (const ep of eps) {
        const url = `${location.origin}${ep}?dosyaId=${encodeURIComponent(dosyaId)}&evrakId=${encodeURIComponent(ev.evrakId)}`;
        const done = await dlViaBg(url, fname);
        if (done) { ok++; _pdfEp = ep; break; }
      }
      await sleep(600); // nazik indirme
    }
    return { ok, total: n };
  }

  const EVRAK_ENDPOINTS = [
    (id) => ["/list_dosya_evraklar.ajx", { dosyaId: id, pageNumber: 1 }],
    (id) => ["/listDosyaEvraklarPageTotal.ajx", { dosyaId: id, pageNumber: 1 }],
    (id) => ["/dosya_evrak_listesi_brd.ajx", { dosyaId: id }],
    (id) => ["/dosyaEvrakListesi.ajx", { dosyaId: id }],
    (id) => ["/evrak_listesi_brd.ajx", { dosyaId: id }],
    (id) => ["/evrak_listesi.ajx", { dosyaId: id }]
  ];
  let _evrakEp = null; // çalışan endpoint'i hatırla
  async function apiEvrak(dosyaId, rec) {
    const tryEp = async (factory) => {
      const [url, body] = factory(dosyaId);
      try { const j = await apiPost(url, body); const list = parseEvrak(j); if (list.length) { _evrakEp = factory; return list; } } catch (e) {}
      return null;
    };
    let list = _evrakEp ? await tryEp(_evrakEp) : null;
    if (!list) { for (const f of EVRAK_ENDPOINTS) { list = await tryEp(f); if (list) break; await sleep(200); } }
    if (list && list.length) {
      rec.evrak = list;
      rec.sonEvrakTarihi = list.map((e) => e.tarih).filter(Boolean).sort().slice(-1)[0] || "";
      const teb = list.map((e) => e.tebligTarihi).filter(Boolean).sort()[0];
      if (teb) rec.tebligTarihi = teb;
    }
  }

  async function getResolvedTargets() {
    const list = await getTargets();
    return list.map((s) => {
      const e = extractEsas(s) || tr(s); const m = e.match(/^(\d{4})\/(\d+)$/);
      return m ? { full: e, yil: m[1], sira: m[2], daire: DAIRE_MAP[e] || "" } : null;
    }).filter(Boolean);
  }

  async function accumulate(rows) {
    const prev = await getAccum();
    const map = new Map(prev.map((x) => [x.dosyaNo, x]));
    rows.forEach((r) => map.set(r.dosyaNo, Object.assign({}, map.get(r.dosyaNo), r)));
    const merged = Array.from(map.values());
    await setAccum(merged);
    return merged;
  }

  // Ham HTTP yanıtı gösteren tanı aracı — neyin patladığını net görmek için
  async function rawPost(path, body) {
    const r = await fetch(path, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json;charset=UTF-8", "X-Requested-With": "XMLHttpRequest" }, body: JSON.stringify(body) });
    const ct = r.headers.get("content-type") || "";
    const txt = await r.text();
    return { status: r.status, ct, txt };
  }

  async function doDiag() {
    bodyEl.innerHTML = `<div class="rucu-sum">🔧 Tanı (2025/39428 · İstanbul 23.) — ham yanıtlar:</div><div id="rucu-diag"></div>`;
    const out = panel.querySelector("#rucu-diag");
    const add = (h) => { const d = document.createElement("div"); d.style.cssText = "font:11px ui-monospace,Consolas,monospace;border-bottom:1px solid #eee;padding:5px 0;white-space:pre-wrap;word-break:break-all"; d.innerHTML = h; out.appendChild(d); };
    add(`Origin: ${esc(location.origin)}`);

    // 1) mahkemeler
    try {
      const m = await rawPost("/avukat_mahkemeleri_sorgula.ajx", { yargiTuru: "2", yargiBirimi: "1101", dosyaKapaliMi: false });
      const isHtml = /<html|<!doctype|<body|login|giriş/i.test(m.txt);
      add(`<b>mahkemeler</b>: HTTP ${m.status} · ${esc(m.ct)} ${isHtml ? "⚠ HTML/LOGIN döndü (çerez gitmiyor!)" : "✓ JSON"}\n${esc(m.txt.slice(0, 200))}`);
      console.log("[Rücu DIAG] mahkemeler", m.status, m.ct, m.txt.slice(0, 800));
    } catch (e) { add(`mahkemeler HATA: ${esc(e.message)}`); }

    // 2) search — birimId'li ve birimId'siz, farklı durumKod
    let mahkList = [];
    try { mahkList = await apiMahkemeler(); } catch (e) {}
    const birimId = findBirimId("İstanbul 23. İcra Dairesi", mahkList);
    add(`mahkeme adedi: ${mahkList.length} · birimId(İstanbul 23.)=${birimId}`);
    if (mahkList[0]) add(`örnek birim: ${esc(JSON.stringify(mahkList[0]).slice(0, 150))}`);

    for (const variant of [{ durumKod: 0, withBirim: true }, { durumKod: 0, withBirim: false }, { durumKod: 1, withBirim: true }, { durumKod: 2, withBirim: true }]) {
      const body = { dosyaDurumKod: variant.durumKod, pageSize: 100, pageNumber: 1, dosyaYil: 2025, dosyaSira: 39428, birimTuru2: "1101" };
      if (variant.withBirim && birimId) body.birimId = String(birimId);
      try {
        const s = await rawPost("/search_phrase_detayli.ajx", body);
        let cnt = "?"; try { const j = JSON.parse(s.txt); const it = Array.isArray(j) ? (Array.isArray(j[0]) ? j[0] : j) : []; cnt = it.length; } catch (e) {}
        add(`<b>search</b> durumKod=${variant.durumKod} birim=${variant.withBirim ? (birimId || "yok") : "—"}: HTTP ${s.status} · sonuç=${cnt}\n${esc(s.txt.slice(0, 280))}`);
        console.log("[Rücu DIAG] search", variant, s.status, s.txt.slice(0, 1200));
      } catch (e) { add(`search HATA: ${esc(e.message)}`); }
      await sleep(800);
    }
    flash("Tanı bitti — bu kutuyu (veya F12 → Console) bana gönder.");
  }

  // Ham evrak JSON dök — PTT barkod alanını bulmak için (Normal Tebligat'lı dosya)
  async function doEvrakRaw() {
    const t = { yil: "2026", sira: "4186", full: "2026/4186", daire: "İzmir 3. İcra Dairesi" };
    bodyEl.innerHTML = `<div class="rucu-sum">🔎 Ham evrak çekiliyor (${t.full})…</div><div id="rucu-diag"></div>`;
    const out = panel.querySelector("#rucu-diag");
    const add = (h) => { const d = document.createElement("div"); d.style.cssText = "font:11px ui-monospace,Consolas,monospace;border-bottom:1px solid #eee;padding:5px 0;white-space:pre-wrap;word-break:break-all"; d.innerHTML = h; out.appendChild(d); };
    try {
      let mahk = []; try { mahk = await apiMahkemeler(); } catch (e) {}
      const birimId = findBirimId(t.daire, mahk);
      const found = await apiSearchDosyaId(t.yil, t.sira, birimId);
      if (!found || !found.dosyaId) { add("⚠ dosya bulunamadı"); return; }
      add("dosyaId alındı, evrak endpoint'leri deneniyor…");
      let raw = null, used = null, items = [];
      for (const f of EVRAK_ENDPOINTS) {
        const [url, body] = f(found.dosyaId);
        try {
          const j = await apiPost(url, body);
          const it = evrakItems(j);
          add(`${esc(url)} → ${it.length} kayıt`);
          if (it.length) { raw = j; used = url; items = it; break; }
        } catch (e) { add(`${esc(url)} → hata: ${esc(e.message)}`); }
        await sleep(250);
      }
      if (!raw) { add("⚠ hiçbir endpoint evrak döndürmedi"); return; }
      const teb = items.find((x) => /tebli|mazbata|barkod|posta/i.test(JSON.stringify(x))) || items[0];
      add(`<b>✓ ${esc(used)} · ${items.length} evrak</b>`);
      add(`<b>İlk tebligat kaydı (tüm alanlar):</b>\n${esc(JSON.stringify(teb, null, 2).slice(0, 1800))}`);
      download("uyap-evrak-ham.json", JSON.stringify({ endpoint: used, dosya: t.full, ilkTebligat: teb, tumEvraklar: items }, null, 2), "application/json");
      flash("uyap-evrak-ham.json indi — bana gönder, barkod alanını bulayım.");
    } catch (e) { add("HATA: " + esc(e.message)); }
  }

  // ====== DAVA (TÜKETİCİ MAHKEMESİ) KEŞFİ ==================================
  // İcra: yargiTuru=2, yargiBirimi=1101. Hukuk/Tüketici kodları BİLİNMİYOR.
  // Bu araç UYAP'ın birim listesini tarayıp "Tüketici Mahkemesi" döndüren
  // yargiTuru/yargiBirimi kodunu bulur. Sadece birim LİSTESİ çeker (harç yok).
  const KESIF_YARGITURU = ["1", "2"];      // Hukuk en olası "1"; "2" icra (kontrol)
  const KESIF_YBIRIMI = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","30","1001","1011","1021","1101","1111"];
  const TUKETICI_RE = /t[üu]ketic/i;

  async function doKesifDava() {
    bodyEl.innerHTML = `<div class="rucu-sum">🔭 <b>Dava (Tüketici Mahkemesi) keşfi</b><br><span class="rucu-mut">UYAP yargı-türü/birim kodlarını tarıyor — yalnız BİRİM LİSTESİ (dosya detayı/safahat DEĞİL → harç yok). ~30-60 sn. UYAP Avukat Portalı açık olmalı.</span></div><div id="rucu-diag"></div>`;
    const out = panel.querySelector("#rucu-diag");
    const add = (h) => { const d = document.createElement("div"); d.style.cssText = "font:11px ui-monospace,Consolas,monospace;border-bottom:1px solid #eee;padding:5px 0;white-space:pre-wrap;word-break:break-all"; d.innerHTML = h; out.appendChild(d); };
    const result = { taranan: new Date().toISOString(), origin: location.origin, url: location.href, hits: [], tuketici: [], selectOptions: [], capturedEndpoints: [] };

    // 1) Form native <select> ise option kod haritasını al (yargı türü/birim)
    try {
      const docs = collectDocs();
      docs.forEach((doc) => {
        let sels = []; try { sels = doc.querySelectorAll("select"); } catch (e) {}
        sels.forEach((s) => {
          const opts = Array.from(s.options || []).map((o) => ({ v: o.value, t: tr(o.textContent) })).filter((o) => o.t);
          if (opts.length) result.selectOptions.push({ ad: s.name || s.id || "", opts });
        });
      });
      if (result.selectOptions.length) add(`📋 form &lt;select&gt; sayısı: ${result.selectOptions.length} (kodlar export'a yazıldı)`);
    } catch (e) {}

    // 2) Aktif kod taraması — birim listesinde "Tüketici" arıyoruz
    let found = false;
    for (const yt of KESIF_YARGITURU) {
      if (found) break;
      for (const yb of KESIF_YBIRIMI) {
        let arr = null;
        try { const j = await apiMahkemelerRaw(yt, yb, false); arr = Array.isArray(j) ? j : ((j && (j.list || j.data)) || null); } catch (e) {}
        const n = Array.isArray(arr) ? arr.length : 0;
        if (n) {
          const tk = arr.filter((m) => TUKETICI_RE.test(m.birimAdi || m.birimAd || m.ad || ""));
          result.hits.push({ yargiTuru: yt, yargiBirimi: yb, count: n, tuketiciCount: tk.length, ornekBirim: arr[0] || {} });
          add(`yt=${yt} yb=${yb} → ${n} birim${tk.length ? ` · ⭐ <b>TÜKETİCİ ${tk.length}</b>` : ""}`);
          if (tk.length) {
            tk.slice(0, 10).forEach((m) => result.tuketici.push({ yargiTuru: yt, yargiBirimi: yb, birimId: m.birimId || m.id || m.birim_id, birimAdi: m.birimAdi || m.birimAd || m.ad }));
            found = true; break;
          }
        }
        await sleep(450); // nazik
      }
    }

    // 3) Pasif yakalama (interceptor) — ilgili uçları ekle
    const cap = window._rucuCap || [];
    const rel = cap.filter((c) => /mahkemeleri_sorgula|search_phrase|evrak|view_document|download_document|hukuk|t[üu]ketic/i.test(c.url || "") || /hukuk|t[üu]ketic/i.test(c.req || ""));
    result.capturedEndpoints = rel.map((c) => ({ url: c.url, method: c.method, req: c.req, resp: (c.resp || "").slice(0, 400) }));
    if (rel.length) add(`🕸 yakalanan ilgili çağrı: ${rel.length} (export'ta)`);

    // 3b) TÜM yakalanan isteklerden yargı kodlarını çıkar — İcra(1101) DIŞI = Hukuk/Tüketici adayı
    const kodSetleri = [];
    cap.forEach((c) => {
      let o = null; try { o = JSON.parse(c.req); } catch (e) { return; }
      if (!o || typeof o !== "object") return;
      const ks = {};
      ["yargiTuru", "yargiBirimi", "birimTuru2", "birimTuru", "dosyaTuru"].forEach((k) => { if (o[k] != null) ks[k] = o[k]; });
      if (Object.keys(ks).length) { ks._url = (c.url || "").split("?")[0]; ks._icraDisi = (String(ks.yargiBirimi || ks.birimTuru2 || "") !== "1101"); kodSetleri.push(ks); }
    });
    result.yargiKodlari = kodSetleri;
    const icraDisi = kodSetleri.filter((k) => k._icraDisi);
    if (icraDisi.length) { add(`<b>🧩 İcra-dışı yargı kodu yakalandı (Hukuk/Tüketici adayı):</b>`); icraDisi.slice(0, 6).forEach((k) => add(`   ${esc(JSON.stringify(k))}`)); }
    // PDF/evrak uç örneği (dava için /main/hukuk/... yolunu görmek için)
    const pdfUrls = rel.filter((c) => /view_document|download_document/i.test(c.url || "")).map((c) => c.url);
    if (pdfUrls.length) { result.pdfEndpointOrnek = pdfUrls.slice(0, 3); add(`<b>📄 PDF uç örneği:</b> ${esc(pdfUrls[0])}`); }

    // 3c) GÜVENLİK AĞI: TÜM yakalanan çağrılar (ARABULUCULUK / kişi-ile-ara endpoint'ini kaçırmamak için)
    result.tumYakalanan = cap.map((c) => ({ url: (c.url || "").split("?")[0], method: c.method, req: (c.req || "").slice(0, 300), resp: (c.resp || "").slice(0, 200) }));
    const kisiCagri = cap.filter((c) => /kisi|kişi|tckn|tckimlik|kimlikno|arabulu/i.test((c.url || "") + " " + (c.req || "")) && !/avukat_mahkemeleri_sorgula/i.test(c.url || ""));
    if (kisiCagri.length) {
      result.kisiSorguAdaylari = kisiCagri.map((c) => ({ url: (c.url || "").split("?")[0], req: (c.req || "").slice(0, 250) }));
      add(`<b>👤 Kişi/TCKN/arabuluculuk sorgu adayı: ${kisiCagri.length}</b>`);
      kisiCagri.slice(0, 5).forEach((c) => add(`   ${esc((c.url || "").split("?")[0])}  ${esc((c.req || "").slice(0, 140))}`));
    }

    // Sonuç
    if (result.tuketici.length) {
      add(`<b>✅ Tüketici Mahkemesi kodları bulundu:</b>`);
      result.tuketici.slice(0, 6).forEach((t) => add(`   yargiTuru=<b>${t.yargiTuru}</b> · yargiBirimi=<b>${t.yargiBirimi}</b> · birimId=${esc(String(t.birimId))} · ${esc(t.birimAdi)}`));
    } else {
      add(`<b>⚠ Otomatik bulunamadı.</b> UYAP'ta Dosya Sorgulama → yargı türü <b>Hukuk → Tüketici Mahkemesi</b> seçip bir sorgu çalıştır, sonra tekrar 🔭 Keşif'e bas (pasif yakalama devreye girer). Ayrıca bu JSON'u bana gönder.`);
    }
    download("uyap-dava-kesif.json", JSON.stringify(result, null, 2), "application/json");
    flash("uyap-dava-kesif.json indi — bana gönder, dava modunu kodlayayım.");
  }

  // ====== DAVA (TÜKETİCİ MAHKEMESİ) — keşiften gelen kesin kodlar =============
  // yargiTuru=1 (Hukuk) · yargiBirimi=0912 (Tüketici Mahkemesi) · search birimTuru2=0912
  const TUKETICI_YARGITURU = "1";
  const TUKETICI_YBIRIMI = "0912";
  const PDF_ENDPOINTS_HUKUK = [
    "/main/hukuk/modules/evrak/view_document_brd.uyap",
    "/main/hukuk/modules/evrak/download_document_brd.uyap"
  ];
  // Dava'da önemli evrak (key indirme modu)
  const ONEMLI_DAVA_RE = /(dava dilek|cevap|bilirki|duru[şs]ma|tensip|ön inceleme|on inceleme|karar|gerekçeli|gerekceli|istinaf|tebli|müzekkere|muzekkere|ıslah|islah|delil|harç|harc|gider avans)/i;

  async function apiTuketiciMahkemeler() {
    const out = [];
    for (const kapali of [false, true]) {
      try { const j = await apiPost("/avukat_mahkemeleri_sorgula.ajx", { yargiTuru: TUKETICI_YARGITURU, yargiBirimi: TUKETICI_YBIRIMI, dosyaKapaliMi: kapali }); if (Array.isArray(j)) out.push(...j); } catch (e) {}
    }
    const seen = new Map();
    out.forEach((m) => { const id = m.birimId || m.id; if (id && !seen.has(id)) seen.set(id, m); });
    return Array.from(seen.values());
  }

  function getDavaTargets() { return new Promise((r) => chrome.storage.local.get(["davaTargets"], (o) => r((o && Array.isArray(o.davaTargets)) ? o.davaTargets : []))); }
  function setDavaTargets(list) { return new Promise((r) => chrome.storage.local.set({ davaTargets: list }, r)); }
  async function getResolvedDavaTargets() {
    const list = await getDavaTargets();
    return list.map((s) => {
      const parts = String(s).split(/\s*[|@;]\s*/);
      const e = extractEsas(parts[0]) || tr(parts[0]); const m = e.match(/^(\d{4})\/(\d+)$/);
      return m ? { full: e, yil: m[1], sira: m[2], mahkeme: tr(parts.slice(1).join(" ")) } : null;
    }).filter(Boolean);
  }

  async function showDavaTargets() {
    const targets = await getDavaTargets();
    bodyEl.innerHTML = `
      <div class="rucu-sec-t">🎯 Dava hedef listesi — her satır: <b>esas | Tüketici Mahkemesi</b></div>
      <textarea class="rucu-ta" id="rucu-dta">${esc(targets.join("\n"))}</textarea>
      <div class="rucu-row" style="margin-top:8px">
        <button class="rucu-btn" id="rucu-dsave">Kaydet</button>
        <button class="rucu-btn sec" id="rucu-dback">← Geri</button>
      </div>
      <div class="rucu-mut" style="margin-top:6px">Örn: <b>2026/415 | İstanbul Anadolu 7. Tüketici Mahkemesi</b> · mahkeme yazmazsan tüm Tüketici mahkemeleri taranır, Ray taraf olan seçilir.</div>`;
    panel.querySelector("#rucu-dsave").addEventListener("click", async () => {
      const lines = panel.querySelector("#rucu-dta").value.split("\n").map((x) => tr(x)).filter(Boolean);
      await setDavaTargets(lines);
      flash("Dava hedef listesi kaydedildi.");
    });
    panel.querySelector("#rucu-dback").addEventListener("click", async () => { const a = await getAccum(); renderReport(a, { mode: "biriktir" }); });
  }

  async function doDavaAuto() {
    if (running) { flash("Zaten çalışıyor…"); return; }
    if (!/uyap\.gov\.tr$/.test(location.hostname)) { flash("UYAP Avukat Portalı sekmesinde çalıştır."); return; }
    running = true;
    bodyEl.innerHTML = `<div class="rucu-sum">▶ <b>Dava (Tüketici Mahkemesi)</b> sorgulanıyor — yargiTuru=1 · yargiBirimi=0912.<br><span class="rucu-mut">Tüketici Mahkemeleri yükleniyor…</span></div><div id="rucu-prog"></div>`;
    const prog = panel.querySelector("#rucu-prog");

    let mahk = [];
    try { mahk = await apiTuketiciMahkemeler(); } catch (e) {}
    const targets = await getResolvedDavaTargets();
    if (!targets.length) { running = false; flash("Dava hedef listesi boş — 🎯 Dava Hedef'ten ekle."); return; }

    let ok = 0, fail = 0;
    for (let i = 0; i < targets.length; i++) {
      const t = targets[i];
      const line = document.createElement("div"); line.className = "rucu-mut";
      line.textContent = `(${i + 1}/${targets.length}) ${t.full} sorgulanıyor…`;
      prog.prepend(line);
      try {
        const birimId = t.mahkeme ? findBirimIdByName(t.mahkeme, mahk) : null;
        let cands = await apiSearchAll(t.yil, t.sira, birimId, TUKETICI_YBIRIMI);
        if (!birimId && t.mahkeme && cands.length > 1) { const f = cands.filter((c) => birimMatch(c.birimAdi, t.mahkeme)); if (f.length) cands = f; }
        if (!cands.length) {
          fail++; line.innerHTML = `⚠ <b>${t.full}</b>: dava bulunamadı <span class="rucu-mut">(${esc(t.mahkeme || "mahkeme yok")})</span>`;
          await sleep(1200); continue;
        }
        let found = cands[0], secimNot = "";
        if (cands.length > 1) {
          line.innerHTML = `🔎 <b>${t.full}</b>: ${cands.length} mahkemede var — Ray taraf olan seçiliyor…`;
          const checked = [];
          for (const c of cands) { await sleep(400); const r = await rayRol(c.dosyaId); checked.push(Object.assign({}, c, r)); }
          const ray = checked.filter((c) => c.tarafRay);
          if (ray.length >= 1) { const dc = ray.filter((c) => c.davaciRay); found = dc[0] || ray[0]; secimNot = `${cands.length} mahkemeden Ray-taraf seçildi`; }
          else {
            fail++;
            const liste = checked.map((c) => `${esc(c.birimAdi || "?")} · ${esc(classifyDurum(c.durum))}`).join("<br>&nbsp;&nbsp;");
            line.innerHTML = `❓ <b>${t.full}</b>: ${cands.length} dosya, Ray taraf değil — elle seç:<br>&nbsp;&nbsp;${liste}`;
            await accumulate([{ dosyaNo: t.full, kaynak: "dava", belirsiz: true }]);
            await sleep(1500); continue;
          }
        }
        const rec = { dosyaNo: t.full, durum: found.durum || "", birim: found.birimAdi || t.mahkeme || "", durumTahmin: classifyDurum(found.durum || ""), kaynak: "dava" };
        if (secimNot) rec.secimNot = secimNot;
        rec.klasor = `dava ${t.full} ${kisaDaire(found.birimAdi)}`.trim();
        line.innerHTML = `⏳ <b>${t.full}</b> <span class="rucu-mut">(${esc(found.birimAdi)})</span>: detay çekiliyor…`;
        await sleep(400); await apiAyrinti(found.dosyaId, rec);
        await sleep(400); await apiEvrak(found.dosyaId, rec);
        const dlSel = panel.querySelector("#rucu-dlmode");
        const dlmode = dlSel ? dlSel.value : "none";
        if (dlmode !== "none" && rec.evrak && rec.evrak.length) {
          let list = rec.evrak;
          if (dlmode === "key") list = rec.evrak.filter((e) => ONEMLI_DAVA_RE.test(`${e.tur || ""} ${e.aciklama || ""}`));
          if (list.length) {
            line.innerHTML = `📥 <b>${t.full}</b>: ${list.length} evrak indiriliyor…`;
            const dl = await downloadEvraklar(rec.klasor, found.dosyaId, list, PDF_ENDPOINTS_HUKUK.concat(PDF_ENDPOINTS));
            rec.evrakIndirilen = dl.ok;
          }
        }
        await accumulate([rec]); ok++;
        const ev = rec.evrak && rec.evrak.length ? ` · ${rec.evrak.length} evrak` : "";
        const dlInfo = rec.evrakIndirilen != null ? ` · 📥 ${rec.evrakIndirilen} indi` : "";
        line.innerHTML = `✅ <b>${t.full}</b> <span class="rucu-mut">[${esc(found.birimAdi)}]</span>: <b>${rec.durumTahmin}</b> <span class="rucu-mut">${esc(rec.durum || "")}${secimNot ? " · " + esc(secimNot) : ""}${ev}${dlInfo}</span>`;
      } catch (e) {
        fail++; line.innerHTML = `❌ <b>${t.full}</b>: ${esc(e.message || "hata")}`;
      }
      await sleep(1500);
    }
    running = false;
    flash(`Dava bitti: ${ok} okundu, ${fail} atlandı.`);
    await doOzet();
  }

  async function doAuto() {
    if (running) { flash("Zaten çalışıyor…"); return; }
    if (!/uyap\.gov\.tr$/.test(location.hostname)) { flash("UYAP Avukat Portalı sekmesinde çalıştır."); return; }
    running = true;
    bodyEl.innerHTML = `<div class="rucu-sum">▶ API ile sorgulanıyor — forma/sayfaya dokunmana gerek yok.<br><span class="rucu-mut">Hedef dosyalar taranıyor… (aynı no birden çok dairede olabilir → RAY ALACAKLI olan seçilir)</span></div><div id="rucu-prog"></div>`;
    const prog = panel.querySelector("#rucu-prog");

    const targets = await getResolvedTargets();
    if (!targets.length) { running = false; flash("Hedef listesi boş."); return; }

    let ok = 0, fail = 0;
    for (let i = 0; i < targets.length; i++) {
      const t = targets[i];
      const line = document.createElement("div"); line.className = "rucu-mut";
      line.textContent = `(${i + 1}/${targets.length}) ${t.full} sorgulanıyor…`;
      prog.prepend(line);
      try {
        // 1) Aynı esas no'nun TÜM adaylarını çek (farklı daireler dahil)
        let cands = await apiSearchAll(t.yil, t.sira, null);
        if (!cands.length) {
          fail++; line.innerHTML = `⚠ <b>${t.full}</b>: dosya bulunamadı`;
          await sleep(1200); continue;
        }

        // 2) Tek aday → onu kullan; birden fazla → RAY ALACAKLI + AÇIK olanı PUANLA-SEÇ
        let found, secimNot = "";
        if (cands.length === 1) {
          found = cands[0];
        } else {
          line.innerHTML = `🔎 <b>${t.full}</b>: ${cands.length} aday — Ray ALACAKLI + AÇIK olan seçiliyor…`;
          const checked = [];
          for (const c of cands) { await sleep(400); const r = await rayRol(c.dosyaId); checked.push(Object.assign({ durTah: durumKodTahmin(c.durumKod, c.durum) }, c, r)); }
          // ÖNCELİK: Ray alacaklı (100) > açık (10) > yazdığın daire (1)
          const score = (c) => (c.alacakliRay ? 100 : 0) + (c.durTah === "AÇIK" ? 10 : 0) + ((t.daire && daireMatch(c.birimAdi, t.daire)) ? 1 : 0);
          checked.sort((a, b) => score(b) - score(a));
          found = checked[0];
          const liste = checked.map((c) => `${esc(c.birimAdi || "?")}·${esc(c.durTah)}${c.alacakliRay ? "·Ray ALACAKLI" : (c.borcluRay ? "·Ray borçlu" : "")}`).join(" | ");
          secimNot = `${cands.length} aday [${liste}] → ${esc(found.birimAdi)}·${found.durTah}`;
          if (!checked.some((c) => c.alacakliRay)) secimNot += " ⚠ Ray ALACAKLI yok, KONTROL ET";
        }

        // 3) Seçilen dosyayı işle  (dosyaId = UYAP iç id → pushEvraklar PDF byte'larını bununla çeker)
        const rec = { dosyaNo: t.full, dosyaId: found.dosyaId, durum: found.durum || "", durumKod: found.durumKod, birim: found.birimAdi || t.daire || "", durumTahmin: durumKodTahmin(found.durumKod, found.durum || ""), kaynak: "api" };
        if (secimNot) rec.secimNot = secimNot;
        rec.klasor = `${t.full} ${kisaDaire(found.birimAdi)}`.trim();
        const drNot = cands.length > 1 ? ` <span class="rucu-mut">(${esc(found.birimAdi)})</span>` : "";
        line.innerHTML = `⏳ <b>${t.full}</b>${drNot}: ${rec.durumTahmin} — detay çekiliyor…`;
        await sleep(400); await apiAyrinti(found.dosyaId, rec);
        await sleep(400); await apiHesap(found.dosyaId, rec);
        await sleep(400); await apiEvrak(found.dosyaId, rec);
        rec.durumTahmin = durumKodTahmin(rec.durumKod, rec.durum || "");
        // Evrak PDF indir (seçili moda göre): none / key / all → klasör daire ile
        const dlSel = panel.querySelector("#rucu-dlmode");
        const dlmode = dlSel ? dlSel.value : "none";
        if (dlmode !== "none" && rec.evrak && rec.evrak.length) {
          let list = rec.evrak;
          if (dlmode === "key") list = rec.evrak.filter((e) => ONEMLI_EVRAK_RE.test(`${e.tur || ""} ${e.aciklama || ""}`));
          if (list.length) {
            line.innerHTML = `📥 <b>${t.full}</b>: ${list.length} evrak indiriliyor…`;
            const dl = await downloadEvraklar(rec.klasor, found.dosyaId, list);
            rec.evrakIndirilen = dl.ok;
          }
        }
        // Evrakları programa yükle (önizleme için) — taze dosyaId + evrak ile (accum/buton sırasına bağımsız)
        if (rec.evrak && rec.evrak.length) {
          line.innerHTML = `📤 <b>${t.full}</b>: evraklar programa yükleniyor…`;
          try { const pe = await pushEvraklar(rec); if (pe > 0) rec.programEvrak = pe; } catch (e) { console.warn("[rucu] pushEvraklar:", e && e.message); }
        }
        await accumulate([rec]); ok++;
        const para = rec.toplamAlacak != null ? ` · alacak ${fmtTL(rec.toplamAlacak)}` : "";
        const bak = rec.bakiye != null ? ` · bakiye ${fmtTL(rec.bakiye)}` : "";
        const ev = rec.evrak && rec.evrak.length ? ` · ${rec.evrak.length} evrak` : "";
        const dlInfo = rec.evrakIndirilen != null ? ` · 📥 ${rec.evrakIndirilen} indi` : "";
        const pInfo = rec.programEvrak ? ` · 📤 ${rec.programEvrak} programa` : "";
        line.innerHTML = `✅ <b>${t.full}</b>${drNot}: <b>${rec.durumTahmin}</b> <span class="rucu-mut">${esc(rec.durum || "")}${secimNot ? " · " + esc(secimNot) : ""}${para}${bak}${ev}${dlInfo}${pInfo}</span>`;
      } catch (e) {
        fail++; line.innerHTML = `❌ <b>${t.full}</b>: ${esc(e.message || "hata")}`;
      }
      await sleep(1500); // insan hızı — UYAP'a nazik
    }
    running = false;
    flash(`Bitti: ${ok} okundu, ${fail} atlandı.`);
    await doOzet(); // özeti otomatik göster — JSON/manuel gerekmez
  }

  // Eklentinin kendi ürettiği yapısal özet (LLM gerekmez)
  function buildOzet(r) {
    const L = [];
    L.push(`■ ${r.dosyaNo}${r.birim ? " — " + r.birim : ""}`);
    L.push(`Durum: ${r.durumTahmin}${r.durum ? " (" + r.durum + ")" : ""}`);
    const para = [];
    const alacak = r.toplamAlacak != null ? r.toplamAlacak : r.asilAlacak;
    if (alacak != null) para.push(`Asıl alacak: ${fmtTL(alacak)}`);
    if (r.islemisFaiz != null) para.push(`İşlemiş faiz: ${fmtTL(r.islemisFaiz)}`);
    if (r.tahsilat != null) para.push(`Tahsilat: ${fmtTL(r.tahsilat)}`);
    if (r.bakiye != null) para.push(`Bakiye: ${fmtTL(r.bakiye)}`);
    if (para.length) L.push(para.join(" · "));
    if (r.tebligTarihi) L.push(`Tebliğ tarihi: ${r.tebligTarihi}`);
    if (r.evrak && r.evrak.length) {
      L.push(`Safahat (${r.evrak.length} evrak${r.sonEvrakTarihi ? " · son " + r.sonEvrakTarihi : ""}):`);
      const sorted = r.evrak.slice().sort((a, b) => (a.tarih || "").localeCompare(b.tarih || ""));
      sorted.slice(-8).forEach((e) => L.push(`   • ${e.tarih || "—"}  ${e.tur || ""}${e.aciklama ? " — " + e.aciklama : ""}`));
    }
    const y = [];
    if (r.durumTahmin === "KAPALI") { y.push("Dosya KAPALI"); if (/tahsil/i.test(r.durum || "")) y.push("haricen/tahsil yoluyla kapanmış görünüyor"); }
    else if (r.durumTahmin === "AÇIK") { y.push("Dosya DERDEST (açık)"); if (r.bakiye != null) y.push(r.bakiye > 0 ? `bakiye ${fmtTL(r.bakiye)} → tahsil sürüyor` : "bakiye 0 → tahsil tamamlanmış olabilir"); }
    if (y.length) L.push("Yorum: " + y.join(", ") + ".");
    return L.join("\n");
  }

  async function doOzet() {
    const accum = await getAccum();
    const withData = accum.filter((r) => r.kaynak === "api" || r.durum);
    if (!withData.length) { flash("Önce ▶ Oto Sorgula çalıştır."); return; }
    const text = withData.map(buildOzet).join("\n\n");
    bodyEl.innerHTML = `<div class="rucu-row"><button class="rucu-btn" id="oz-copy">📋 Kopyala</button><button class="rucu-btn sec" id="oz-dl">⬇ Özet indir</button><button class="rucu-btn sec" id="oz-back">← Tablo</button></div><pre style="white-space:pre-wrap;font:12px ui-monospace,Consolas,monospace;background:#f8f8f8;border:1px solid #eee;border-radius:8px;padding:8px;margin:0">${esc(text)}</pre>`;
    panel.querySelector("#oz-copy").addEventListener("click", async () => { const ok = await copy(text); flash(ok ? "Özet panoya kopyalandı." : "Kopyalama olmadı."); });
    panel.querySelector("#oz-dl").addEventListener("click", () => download("rucu-ozet.txt", text, "text/plain"));
    panel.querySelector("#oz-back").addEventListener("click", () => renderReport(accum, { mode: "biriktir" }));
  }

  async function renderReport(rows, meta) {
    const targets = await getTargets();
    const tset = Array.from(new Set(targets.map((t) => extractEsas(t) || tr(t))));
    const byNo = new Map(rows.map((r) => [r.dosyaNo, r]));
    const targetRows = tset.map((t) => byNo.get(t) || { dosyaNo: t, durum: "", durumTahmin: "YOK", _missing: true });
    const acik = targetRows.filter((r) => r.durumTahmin === "AÇIK").length;
    const kapali = targetRows.filter((r) => r.durumTahmin === "KAPALI").length;
    const eksik = targetRows.filter((r) => r._missing).length;

    lastReport = {
      taranan: new Date().toISOString(), url: location.href, mod: meta.mode,
      biriktirilenToplam: rows.length, hedefToplam: tset.length,
      ozet: { acik, kapali, belirsiz: targetRows.length - acik - kapali - eksik, henuzSorgulanmadi: eksik },
      hedefDosyalar: targetRows, tumKayitlar: rows
    };

    let html = `<div class="rucu-sum">`;
    if (meta.mode === "biriktir") {
      html += `Biriktirilen: <b>${rows.length}</b> dosya`;
      if (meta.added !== undefined) html += ` · bu sorguda yeni: <b>${meta.added}</b>`;
      if (meta.restored) html += ` <span class="rucu-mut">(önceki oturumdan)</span>`;
      html += `<br>`;
    } else {
      html += `Bu sayfada okunan: <b>${rows.length}</b> dosya <span class="rucu-mut">(${(meta.scanInfo && meta.scanInfo.mode) || ""})</span><br>`;
    }
    html += `Hedef 6 dosya → 🟢 Açık: <b>${acik}</b> · 🔴 Kapalı: <b>${kapali}</b> · ⚪ Henüz yok: <b>${eksik}</b></div>`;

    html += `<div class="rucu-sec-t">🎯 Hedef rücu dosyaları</div>`;
    html += rowsTable(targetRows, true);

    if (rows.length) {
      html += `<details><summary class="rucu-sec-t">Tüm biriktirilen kayıtlar (${rows.length})</summary>${rowsTable(rows, false)}</details>`;
    }
    bodyEl.innerHTML = html;
  }

  function badge(r) {
    if (r._missing) return `<span class="rucu-badge b-yok">henüz yok</span>`;
    if (r.durumTahmin === "AÇIK") return `<span class="rucu-badge b-acik">AÇIK</span>`;
    if (r.durumTahmin === "KAPALI") return `<span class="rucu-badge b-kapali">KAPALI</span>`;
    return `<span class="rucu-badge b-belirsiz">?</span>`;
  }
  function rowsTable(rows, isTarget) {
    let h = `<table class="rucu-tbl"><thead><tr><th>Dosya No</th><th>Durum</th><th>Alacak / Bakiye</th></tr></thead><tbody>`;
    rows.forEach((r) => {
      const alacak = r.toplamAlacak != null ? fmtTL(r.toplamAlacak) : (r.asilAlacak != null ? fmtTL(r.asilAlacak) : "");
      const faiz = r.islemisFaiz != null ? `<br><span class="rucu-mut">faiz ${esc(fmtTL(r.islemisFaiz))}</span>` : "";
      const bakiye = r.bakiye != null ? `<br><span class="rucu-mut">bakiye ${esc(fmtTL(r.bakiye))}</span>` : "";
      const ev = (r.evrak && r.evrak.length) ? `<br><span class="rucu-mut">${r.evrak.length} evrak${r.sonEvrakTarihi ? " · son " + esc(r.sonEvrakTarihi) : ""}</span>` : "";
      h += `<tr>
        <td><b>${esc(r.dosyaNo)}</b><br><span class="rucu-mut">${esc(r.birim || "—")}</span></td>
        <td>${badge(r)}${r.durum ? `<br><span class="rucu-mut">${esc(r.durum)}</span>` : (r._missing ? `<br><span class="rucu-mut">sorgula</span>` : "")}</td>
        <td>${alacak ? esc(alacak) : "—"}${faiz}${bakiye}${ev}</td>
      </tr>`;
    });
    return h + `</tbody></table>`;
  }
  function esc(s) { return tr(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }

  async function showTargets() {
    const targets = await getTargets();
    bodyEl.innerHTML = `
      <div class="rucu-sec-t">🎯 Hedef dosya listesi (her satıra bir esas no)</div>
      <textarea class="rucu-ta" id="rucu-ta">${esc(targets.join("\n"))}</textarea>
      <div class="rucu-row" style="margin-top:8px">
        <button class="rucu-btn" id="rucu-save">Kaydet</button>
        <button class="rucu-btn sec" id="rucu-back">← Geri</button>
      </div>
      <div class="rucu-mut" style="margin-top:6px">Örn: 2026/32147 — Rucu_Takip.xlsx icra dosya no'ları.</div>`;
    panel.querySelector("#rucu-save").addEventListener("click", async () => {
      const lines = panel.querySelector("#rucu-ta").value.split("\n").map((x) => tr(x)).filter(Boolean);
      await setTargets(lines.length ? lines : DEFAULT_TARGETS.slice());
      flash("Hedef liste kaydedildi.");
      const a = await getAccum(); renderReport(a, { mode: "biriktir" });
    });
    panel.querySelector("#rucu-back").addEventListener("click", async () => { const a = await getAccum(); renderReport(a, { mode: "biriktir" }); });
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    if (msg.type === "RUCU_TOGGLE") togglePanel();
    else if (msg.type === "RUCU_AUTO_SYNC") otoSenkron();
  });
  // İlk açılış + her UYAP yüklemesinde (yapılandırılmışsa, 25 dk throttle) otomatik senkron — müşteri hiç tıklamaz.
  chrome.storage.local.get(["senkronToken", "sonOtoSync"], (o) => {
    if (o && o.senkronToken && Date.now() - (o.sonOtoSync || 0) > 25 * 60000) setTimeout(otoSenkron, 20000);
  });

  // MAIN-world ağ-dinleyiciden gelen yakalamaları biriktir
  window.addEventListener("message", (e) => {
    if (e.source === window && e.data && e.data.source === "rucu-intercept" && e.data.rec) {
      if (!window._rucuCap) window._rucuCap = [];
      window._rucuCap.push(e.data.rec);
      if (window._rucuCap.length > 400) window._rucuCap.shift();
    }
  });

  function doCaptured() {
    const cap = window._rucuCap || [];
    const hits = cap.filter((c) => c.hit);
    let html = `<div class="rucu-sum">🕸 Yakalanan ağ çağrısı: <b>${cap.length}</b> · barkod/tebligat içeren: <b>${hits.length}</b></div>`;
    if (cap.length) html += `<div class="rucu-row"><button class="rucu-btn" id="cap-dl">⬇ Tümünü indir</button></div>`;
    const show = hits.length ? hits : cap.slice(-12);
    show.forEach((c) => {
      html += `<div style="font:11px ui-monospace,Consolas,monospace;border-bottom:1px solid #eee;padding:5px 0;white-space:pre-wrap;word-break:break-all">${c.hit ? "⭐ " : ""}<b>${esc(c.url)}</b>\nreq: ${esc(c.req)}\nresp: ${esc((c.resp || "").slice(0, 400))}</div>`;
    });
    if (!cap.length) html += `<div class="rucu-mut">Henüz çağrı yok. UYAP'ta <b>Tebligat İşlemleri / Tebligatlarım</b> ekranını aç (ya da bir dosyanın tebligat sekmesine gir), sonra bu düğmeye tekrar bas.</div>`;
    bodyEl.innerHTML = html;
    const dl = panel.querySelector("#cap-dl");
    if (dl) dl.addEventListener("click", () => download("uyap-yakalananlar.json", JSON.stringify(cap, null, 2), "application/json"));
  }

  if (document.body) buildUi();
  else document.addEventListener("DOMContentLoaded", buildUi);
})();
