/**
 * Rücu Takip — MAIN-world ağ yakalayıcı · interceptor.js (SALT-OKUMA)
 * UYAP sayfasının KENDİ yaptığı fetch/XHR çağrılarının yanıtlarını content script'e iletir.
 * Amaç: "Ödeme İşlemlerim" gibi ekranların endpoint'ini tahmin etmeden, sayfa listeleyince
 * gelen gerçek veriyi okumak. Hiçbir isteği DEĞİŞTİRMEZ, yeni istek ÜRETMEZ.
 */
(() => {
  if (window.__rucuIntc) return;
  window.__rucuIntc = true;
  // ilgi filtresi: .ajx uçları + ödeme/masraf/makbuz benzeri yollar (gürültüyü sınırla)
  const ILGI = /\.ajx|\.uyap|odeme|tahsilat|reddiyat|makbuz|masraf|harc|barokart/i;
  const gonder = (rec) => { try { window.postMessage({ source: "rucu-intercept", rec }, "*"); } catch (e) {} };

  const of = window.fetch;
  window.fetch = async function (input, init) {
    const url = typeof input === "string" ? input : (input && input.url) || "";
    const resp = await of.apply(this, arguments);
    try {
      if (ILGI.test(url)) {
        const klon = resp.clone();
        klon.text().then((t) => gonder({ url: String(url), req: init && init.body ? String(init.body).slice(0, 2000) : "", resp: t.slice(0, 500000), t: Date.now() })).catch(() => {});
      }
    } catch (e) {}
    return resp;
  };

  const oOpen = XMLHttpRequest.prototype.open;
  const oSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, url) { this.__rucuUrl = String(url || ""); return oOpen.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (body) {
    if (ILGI.test(this.__rucuUrl || "")) {
      this.addEventListener("load", () => {
        try { gonder({ url: this.__rucuUrl, req: body ? String(body).slice(0, 2000) : "", resp: String(this.responseText || "").slice(0, 500000), t: Date.now() }); } catch (e) {}
      });
    }
    return oSend.apply(this, arguments);
  };
})();
