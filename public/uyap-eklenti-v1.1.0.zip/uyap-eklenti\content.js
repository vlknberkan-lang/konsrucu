/**
 * Rücu Takip — UYAP Senkron v1.0.0 · content.js (TAM YENİDEN YAZIM)
 *
 * ESKİDEN FARKI (v0.6.x → v1):
 *  1) KİMLİK = (İCRA DAİRESİ + ESAS NO) ÇİFTİ. Esas no tek başına kimlik DEĞİL — aynı esas no
 *     farklı dairelerde başka dosyadır ve aynı numaradan büroya birden çok dosya gelebilir.
 *     Sorgu birimId İLE yapılır; daire çözülemezse / dosya o dairede yoksa bu bir SONUÇTUR.
 *  2) BULUNAMAYAN DOSYA SESSİZ KALMAZ: her hedef için eşleşme sonucu (OK / DAIRE_EKSIK /
 *     DAIRE_COZULEMEDI / BULUNAMADI / BASKA_DAIRE / COKLU_BELIRSIZ / HATA) programa RAPORLANIR —
 *     programda "senkron dışı" dosya kalmaz, neden'i görünür.
 *  3) ÇOKLU EŞLEŞME: aynı (daire, esas) 1'den çok dosya dönerse taraf sorgusuyla ALACAKLISI
 *     tenant unvanı (Ray/Zurich — programdan gelir, hard-code YOK) olan seçilir; net kazanan
 *     yoksa COKLU_BELIRSIZ raporu düşer (aday listesiyle) → avukat elle karar verir.
 *  4) Program dosya kimliği (dosyaId) her gönderide taşınır → programda kesin eşleşme.
 *  5) Masraf toplayıcı MODÜLER: masrafTopla(dosyaId, rec) iskeleti hazır — kaynak ekran
 *     belirlenince (Berkan gösterecek) tek fonksiyon doldurulacak.
 *
 * UYAP uçları v0.6.7'den taşındı (deneme-yanılmayla kanıtlanmış):
 *   /avukat_mahkemeleri_sorgula.ajx · /search_phrase_detayli.ajx · /dosyaAyrintiBilgileri_brd.ajx
 *   /dosya_hesap_bilgileri.ajx · /dosya_taraf_bilgileri_brd.ajx · evrak/safahat uç aileleri
 * SADECE OKUR — UYAP'a hiçbir yazma isteği göndermez.
 */
(() => {
  "use strict";
  if (window.__rucuV1) return;
  window.__rucuV1 = true;

  // ═══════════════ yardımcılar ═══════════════
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const tr = (s) => String(s == null ? "" : s).trim();
  const norm = (s) => tr(s).toLocaleLowerCase("tr").replace(/\s+/g, " ");
  const esc = (s) => tr(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const ESAS_RE = /\b((?:19|20)\d{2})\s*\/\s*(\d{1,7})\b/;
  function extractEsas(text) { const m = tr(text).match(ESAS_RE); return m ? `${m[1]}/${m[2]}` : ""; }
  function fmtTL(n) { try { return Number(n).toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " TL"; } catch (e) { return String(n); } }

  // UYAP tarih alanları her biçimde gelebilir (obje/epoch/dd.mm.yyyy/ISO) → ISO gün
  function detectDate(val) {
    if (val == null || val === "" || val === 0) return "";
    if (typeof val === "object") {
      if (val.date && typeof val.date === "object" && val.date.year)
        return `${val.date.year}-${String(val.date.month || 1).padStart(2, "0")}-${String(val.date.day || 1).padStart(2, "0")}`;
      if (typeof val.time === "number") { const d = new Date(val.time); if (!isNaN(d.getTime()) && d.getFullYear() > 2000 && d.getFullYear() < 2100) return d.toISOString().slice(0, 10); }
      return "";
    }
    if (typeof val === "number") { if (val > 978307200000 && val < 4102444800000) { const d = new Date(val); if (!isNaN(d.getTime())) return d.toISOString().slice(0, 10); } return ""; }
    const s = String(val).trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
    const m = s.match(/^(\d{1,2})[.\/](\d{1,2})[.\/](\d{4})/);
    if (m) return `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
    return "";
  }

  const RE_KAPALI = /(KAPA|ARŞİV|ARSIV|DÜŞ|DUS|HİTAM|HITAM|ZAMANAŞIM|ZAMANASIM|FERAGAT|İNFAZEN|INFAZEN|İPTAL|IPTAL)/;
  const RE_ACIK = /(DERDEST|AÇIK|ACIK|FAAL|DEVAM|İŞLEMDE|ISLEMDE)/;
  function durumTahmin(kod, raw) {
    const R = tr(raw).toLocaleUpperCase("tr-TR");
    if (RE_KAPALI.test(R)) return "KAPALI";
    if (RE_ACIK.test(R)) return "AÇIK";
    if (kod === 0 || kod === "0") return "AÇIK";
    if (kod === 1 || kod === "1") return "KAPALI";
    return "BELİRSİZ";
  }

  // ═══════════════ storage + program köprüsü ═══════════════
  const st = (keys) => new Promise((r) => chrome.storage.local.get(keys, (o) => r(o || {})));
  const stSet = (obj) => new Promise((r) => chrome.storage.local.set(obj, r));
  const sendBg = (msg) => new Promise((res) => { try { chrome.runtime.sendMessage(msg, (r) => res(r || { ok: false, error: "bg yanıtsız" })); } catch (e) { res({ ok: false, error: e.message }); } });

  // ═══════════════ UYAP API katmanı (salt-okuma) ═══════════════
  async function apiPost(path, body) {
    const resp = await fetch(path, {
      method: "POST", credentials: "include",
      headers: { "Content-Type": "application/json;charset=UTF-8", "X-Requested-With": "XMLHttpRequest" },
      body: JSON.stringify(body),
    });
    if (!resp.ok) throw new Error(path.replace(/^\//, "").replace(".ajx", "") + " HTTP " + resp.status);
    const txt = await resp.text();
    try { return JSON.parse(txt); } catch (e) { throw new Error("yanıt JSON değil (oturum düşmüş olabilir): " + txt.slice(0, 60)); }
  }

  // İcra daireleri listesi (yargiTuru=2 İcra, yargiBirimi=1101 İcra Dairesi; açık+kapalı birleşik) — 10 dk önbellek
  let _birimler = null, _birimlerAt = 0;
  async function birimlerYukle() {
    if (_birimler && Date.now() - _birimlerAt < 10 * 60000) return _birimler;
    const out = [];
    for (const kapali of [false, true]) {
      try {
        const j = await apiPost("/avukat_mahkemeleri_sorgula.ajx", { yargiTuru: "2", yargiBirimi: "1101", dosyaKapaliMi: kapali });
        if (Array.isArray(j)) out.push(...j);
      } catch (e) { /* biri patlarsa diğeri kalsın */ }
      await sleep(150);
    }
    const seen = new Map();
    for (const m of out) {
      const id = m.birimId || m.id || m.birim_id; const ad = m.birimAdi || m.birimAd || m.ad || "";
      if (id && !seen.has(String(id))) seen.set(String(id), { birimId: String(id), birimAdi: String(ad) });
    }
    _birimler = Array.from(seen.values());
    _birimlerAt = Date.now();
    return _birimler;
  }

  // Daire adı → birimId. Sıra: tam eşleşme → "genel" eki toleranslı → içerme → şehir + "N. icra" numarası.
  function birimCoz(daireAdi, birimler) {
    if (!daireAdi || !Array.isArray(birimler)) return null;
    const temiz = (s) => norm(s).replace(/\bgenel\b/g, "").replace(/\s+/g, " ").trim();
    const hedef = temiz(daireAdi);
    if (!hedef) return null;
    for (const b of birimler) if (temiz(b.birimAdi) === hedef) return b;
    for (const b of birimler) { const a = temiz(b.birimAdi); if (a && (a.includes(hedef) || hedef.includes(a))) return b; }
    const num = hedef.match(/(\d+)\.\s*icra/);
    const sehir = hedef.split(" ")[0];
    if (num) for (const b of birimler) { const a = temiz(b.birimAdi); if (a.startsWith(sehir) && a.includes(num[1] + ".") && a.includes("icra")) return b; }
    // numarasız tek daire ("Balıkesir İcra Dairesi"): şehir eşleşen ve numara içermeyen tek aday
    if (!num) { const adaylar = birimler.filter((b) => { const a = temiz(b.birimAdi); return a.startsWith(sehir) && a.includes("icra") && !/\d+\./.test(a); }); if (adaylar.length === 1) return adaylar[0]; }
    return null;
  }

  // (yıl, sıra) → dosya adayları. birimId verilirse O DAİREDE arar (kimlik = daire+esas).
  // dosyaDurumKod 2/0/1 hepsi taranıp birleştirilir (açık dosya bazen yalnız 0'da gelir).
  async function dosyaAra(yil, sira, birimId) {
    const full = `${yil}/${sira}`;
    const seen = new Map();
    for (const durumKod of [2, 0, 1]) {
      const body = { dosyaDurumKod: durumKod, pageSize: 100, pageNumber: 1, dosyaYil: parseInt(yil, 10), dosyaSira: parseInt(sira, 10), birimTuru2: "1101" };
      if (birimId) body.birimId = String(birimId);
      let json;
      try { json = await apiPost("/search_phrase_detayli.ajx", body); } catch (e) { continue; }
      const items = Array.isArray(json) ? (Array.isArray(json[0]) ? json[0] : json) : [];
      for (const x of items) {
        if (!x || !x.dosyaId) continue;
        const esas = extractEsas(x.dosyaNo || `${x.dosyaYil}/${x.dosyaSiraNo || x.dosyaSira || ""}`);
        if (esas && esas !== full) continue;
        const durum = x.dosyaDurum || "";
        if (!seen.has(x.dosyaId)) seen.set(x.dosyaId, {
          dosyaId: x.dosyaId, dosyaNo: full, durum, durumKod: x.dosyaDurumKod,
          birimAdi: x.birimAdi || "", birimId: String(x.birimId || ""), acilis: detectDate(x.dosyaAcilisTarihi),
        });
        else if (!seen.get(x.dosyaId).durum && durum) seen.get(x.dosyaId).durum = durum;
      }
      await sleep(250);
    }
    return Array.from(seen.values());
  }

  async function taraflar(dosyaId) {
    const j = await apiPost("/dosya_taraf_bilgileri_brd.ajx", { dosyaId });
    const arr = Array.isArray(j) ? j : (j.taraflar || j.list || j.data || []);
    return arr.map((t) => ({
      ad: t.adi || t.ad || t.adSoyad || "", rol: t.rol || t.tarafTuru || t.sifat || "",
      tip: t.kisiKurum || "", tckn: t.tcKimlikNo || t.tckn || "", vekil: t.vekil || "",
    }));
  }

  async function ayrinti(dosyaId, rec) {
    try {
      const j = await apiPost("/dosyaAyrintiBilgileri_brd.ajx", { dosyaId });
      if (!rec.durum && (j.dosyaDurumu || j.dosyaDurum)) rec.durum = j.dosyaDurumu || j.dosyaDurum;
      if (!rec.birim && j.birimAdi) rec.birim = j.birimAdi;
      const asamaAday = j.dosyaSafhasi || j.takipDurumu || j.takipDurum || j.dosyaAsamasi || j.asama || j.sonIslem || j.sonIslemTuru || j.dosyaDurumAciklama || "";
      if (asamaAday) rec.asama = String(asamaAday);
      if (j.alacakKalemToplamTutar != null) rec.toplamAlacak = j.alacakKalemToplamTutar;
      if (j.alacakKalemFaizTutar != null) rec.islemisFaiz = j.alacakKalemFaizTutar;
      if (j.tahsilHarci != null) rec.tahsilHarci = j.tahsilHarci;
      if (j.takipSonrasiMasraf != null) rec.masraf = j.takipSonrasiMasraf;
      if (j.vekaletUcreti != null) rec.vekalet = j.vekaletUcreti;
      if (j.yapilmisBorcTahsilati != null) rec.tahsilat = j.yapilmisBorcTahsilati;
      if (rec.toplamAlacak != null && rec.tahsilat != null) rec.bakiye = rec.toplamAlacak - rec.tahsilat;
    } catch (e) { rec._ayrintiHata = e.message; }
  }

  async function hesap(dosyaId, rec) {
    try {
      const j = await apiPost("/dosya_hesap_bilgileri.ajx", { dosyaId });
      const items = Array.isArray(j) ? j : [];
      rec.kalemler = rec.kalemler || [];
      const MAP = {
        "Takipte Kesinlesen Miktar": "asilAlacak", "Toplam Faiz Miktari": "islemisFaiz",
        "Vekalet Ücreti": "vekalet", "Vekalet Ucreti": "vekalet", "Masraf Miktari": "masraf",
        "Tahsil Harcı": "tahsilHarci", "Tahsil Harci": "tahsilHarci", "Toplam Alacak": "toplamAlacak",
        "Yatan Para": "tahsilat", "Bakiye Borç Miktari": "bakiye", "Bakiye Borc Miktari": "bakiye",
      };
      for (const it of items) {
        if (!it || typeof it !== "object") continue;
        const ad = it.textAlan || it.kalemAdi || it.aciklama || it.adi || "";
        const tutar = it.degerAlan != null ? it.degerAlan : (it.tutar != null ? it.tutar : it.miktar);
        if (ad && tutar != null) {
          rec.kalemler.push({ ad: String(ad), tutar: Number(tutar) });
          const f = MAP[ad]; if (f && rec[f] == null) rec[f] = Number(tutar);
        }
      }
      if (rec.bakiye == null && rec.toplamAlacak != null && rec.tahsilat != null) rec.bakiye = rec.toplamAlacak - rec.tahsilat;
    } catch (e) { rec._hesapHata = e.message; }
  }

  // ═══════════════ MASRAF — "Ödeme İşlemlerim" ekranından (ağ yakalayıcıyla) ═══════════════
  // Karar (2026-07-04): masraf kaynağı = https://avukat.uyap.gov.tr/odeme-islemlerim — büronun
  // YAPTIĞI ödemelerin defteri (harç/masraf/barokart, makbuz no'suyla) = faturalanacak "bizim taraf"
  // kalemlerinin ta kendisi; üstelik TEK ekranda tüm dosyalar. Endpoint TAHMİN EDİLMEZ: interceptor.js
  // sayfanın kendi listelediği yanıtı yakalar, buradaki ayrıştırıcı kalemleri çıkarır.
  // Akış: kullanıcı Ödeme İşlemlerim'i açıp listeler → panelde "💰 Masraf Tara" → önizleme → "Programa Gönder".

  // MAIN-world yakalamaları biriktir (ring buffer)
  const _cap = [];
  window.addEventListener("message", (e) => {
    if (e.source === window && e.data && e.data.source === "rucu-intercept" && e.data.rec) {
      _cap.push(e.data.rec);
      if (_cap.length > 200) _cap.shift();
    }
  });

  // "1.234,56" / "1234.56" / 1234.56 → sayı (masraf tutarları için; bozuksa NaN)
  function paraSayi(v) {
    if (typeof v === "number") return v;
    const c = String(v == null ? "" : v).replace(/[^\d.,-]/g, "");
    if (!c) return NaN;
    const cok = c.split(",").length - 1 > 1;
    if (!cok && c.includes(",") && c.lastIndexOf(",") > c.lastIndexOf(".")) return Number(c.replace(/\./g, "").replace(",", "."));
    return Number(c.replace(/,/g, ""));
  }

  // Yakalanan JSON'lardan ödeme satırlarını çıkar. Şema bilinmediği için alan adları desenle bulunur;
  // ham indirme düğmesi her zaman yedek (ayrıştırıcı bir alanı kaçırırsa ham JSON'la sertleştirilir).
  function masrafSatirlariCikar() {
    const satirlar = [];
    const gorulen = new Set();
    for (const c of _cap) {
      let j; try { j = JSON.parse(c.resp); } catch (e) { continue; }
      // aday dizileri topla (kök dizi / bilinen liste alanları / 1 seviye içeride)
      const diziler = [];
      const kokAl = (o) => {
        if (Array.isArray(o)) { diziler.push(o); return; }
        if (o && typeof o === "object") for (const k of Object.keys(o)) { const v = o[k]; if (Array.isArray(v) && v.length && typeof v[0] === "object") diziler.push(v); }
      };
      kokAl(j); if (!Array.isArray(j) && j && typeof j === "object") for (const k of Object.keys(j)) kokAl(j[k]);
      for (const arr of diziler) {
        const ilk = arr[0] || {};
        const anahtarlar = Object.keys(ilk);
        const tutarKey = anahtarlar.find((k) => /tutar|miktar|odenen|toplam/i.test(k) && !/vergi|oran/i.test(k));
        if (!tutarKey) continue;
        const tarihliMi = anahtarlar.some((k) => /tarih/i.test(k));
        const makbuzluMu = anahtarlar.some((k) => /makbuz|dekont|seri|belge|islemno|referans/i.test(k));
        if (!tarihliMi && !makbuzluMu) continue; // tutarlı ama tarihsiz+makbuzsuz dizi → başka bir liste
        for (const it of arr) {
          if (!it || typeof it !== "object") continue;
          const tutar = paraSayi(it[tutarKey]);
          if (!Number.isFinite(tutar) || tutar <= 0) continue;
          let tarih = "";
          for (const k of Object.keys(it)) if (/tarih/i.test(k)) { const d = detectDate(it[k]); if (d) { tarih = d; break; } }
          let makbuz = "";
          for (const k of Object.keys(it)) if (/makbuz|dekont|seri|belgeno|islemno|referans/i.test(k)) { const v = tr(it[k]); if (v && v !== "0") { makbuz = v.slice(0, 60); break; } }
          let ad = "";
          for (const k of Object.keys(it)) if (/aciklama|islemtur|odemetur|odemetip|kanal|^tur$|turu$|kalem/i.test(k)) { const v = tr(it[k]); if (v) { ad = v.slice(0, 200); break; } }
          // dosya bağlantısı: herhangi bir string alanda esas no + birim/daire alanı
          let esas = "", birim = "";
          for (const k of Object.keys(it)) {
            const v = it[k];
            if (typeof v !== "string") continue;
            if (!esas) { const e2 = extractEsas(v); if (e2) esas = e2; }
            if (!birim && /birim|daire|mahkeme|icra/i.test(k) && v.trim()) birim = v.trim().slice(0, 120);
          }
          const kimlik = [makbuz, tarih, Math.round(tutar * 100), esas].join("|");
          if (gorulen.has(kimlik)) continue;
          gorulen.add(kimlik);
          satirlar.push({ tarih, ad: ad || "UYAP ödemesi", tutar: Math.round(tutar * 100) / 100, makbuzNo: makbuz || null, esas, birim, _url: c.url });
        }
      }
    }
    return satirlar;
  }

  // Satırları program dosyalarıyla eşleştir (esas → adaylar; birden çoksa BİRİM ile ayrıştır — daire+esas kimliği).
  // TÜM anahtarların (Ray + Zurich) TÜM aktif dosyaları taranır (?tazeSaat=0); her dosya kendi token'ını taşır.
  async function masrafEslestir(satirlar) {
    const tokenlar = await anahtarlar();
    const esasMap = new Map(); // esas → [{id, daire, token}]
    for (const token of tokenlar) {
      const hr = await sendBg({ type: "RUCU_HEDEFLER", tumu: true, token });
      const tum = (hr.ok && hr.data && hr.data.ok && Array.isArray(hr.data.hedefler)) ? hr.data.hedefler : [];
      for (const h of tum) { const e2 = extractEsas(h.icraDosyaNo); if (!e2) continue; if (!esasMap.has(e2)) esasMap.set(e2, []); esasMap.get(e2).push({ id: h.id, daire: h.daire || "", token }); }
    }
    const dosyaBazli = new Map(); // programId → { icraDosyaNo, token, kalemler: [] }
    const eslesmeyen = [];
    for (const s of satirlar) {
      const adaylar = s.esas ? (esasMap.get(s.esas) || []) : [];
      let secilen = null;
      if (adaylar.length === 1) secilen = adaylar[0];
      else if (adaylar.length > 1 && s.birim) secilen = adaylar.find((a) => a.daire && (norm(a.daire).includes(norm(s.birim).split(" ")[0]) || norm(s.birim).includes(norm(a.daire).split(" ")[0]))) || null;
      if (!secilen) { eslesmeyen.push(s); continue; }
      if (!dosyaBazli.has(secilen.id)) dosyaBazli.set(secilen.id, { icraDosyaNo: s.esas, token: secilen.token, kalemler: [] });
      dosyaBazli.get(secilen.id).kalemler.push({ tarih: s.tarih || null, ad: s.ad, tutar: s.tutar, makbuzNo: s.makbuzNo });
    }
    return { dosyaBazli, eslesmeyen };
  }

  async function masrafTara() {
    const satirlar = masrafSatirlariCikar();
    if (!satirlar.length) {
      durumYaz(`💰 Yakalanan ödeme kalemi yok.<br><span class="rucu-mut">1) UYAP menüsünden <b>Ödeme İşlemlerim</b>'i aç · 2) tarih aralığını seçip <b>listele</b> (sayfa sayfa gez) · 3) bu düğmeye tekrar bas. Liste yüklendiyse ama hâlâ boşsa <b>⬇ Ham</b> ile indirip Berkan'a gönder — ayrıştırıcı sertleştirilir.</span>`);
      return;
    }
    durumYaz(`💰 ${satirlar.length} ödeme kalemi bulundu, dosyalarla eşleştiriliyor…`);
    const { dosyaBazli, eslesmeyen } = await masrafEslestir(satirlar);
    let toplamKalem = 0; dosyaBazli.forEach((d) => { toplamKalem += d.kalemler.length; });
    const ozet = `💰 <b>${satirlar.length}</b> kalem yakalandı → <b>${toplamKalem}</b> kalem <b>${dosyaBazli.size}</b> dosyayla eşleşti · <b>${eslesmeyen.length}</b> eşleşmedi (dosya no'suz/başka dosya).`;
    const liste = Array.from(dosyaBazli.entries()).slice(0, 12).map(([, d]) => `• ${esc(d.icraDosyaNo)}: ${d.kalemler.length} kalem, ${fmtTL(d.kalemler.reduce((s2, k) => s2 + k.tutar, 0))}`).join("<br>");
    durumYaz(`${ozet}<br>${liste}${dosyaBazli.size > 12 ? "<br>…" : ""}<br>
      <button class="rucu-btn" id="rucu-msend">📤 Programa Gönder</button>
      <button class="rucu-btn sec" id="rucu-mraw">⬇ Ham</button>`);
    durumEl.querySelector("#rucu-mraw").addEventListener("click", () => {
      const blob = new Blob([JSON.stringify({ satirlar, yakalanan: _cap.map((c) => ({ url: c.url, resp: c.resp.slice(0, 100000) })) }, null, 2)], { type: "application/json" });
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "uyap-odeme-ham.json"; a.click();
    });
    durumEl.querySelector("#rucu-msend").addEventListener("click", async () => {
      let ok = 0, hata = 0, yeni = 0;
      for (const [programId, d] of dosyaBazli) {
        const r = await sendBg({ type: "RUCU_SENKRON", token: d.token, body: { dosyaId: programId, icraDosyaNo: d.icraDosyaNo, masraflar: d.kalemler } });
        if (r.ok && r.data && r.data.ok) { ok++; yeni += r.data.yeniMasraf || 0; } else hata++;
        await sleep(300);
      }
      flash(`Masraf gönderimi: ${ok} dosya · ${yeni} YENİ kalem yazıldı (mükerrerler sunucuda elendi)${hata ? ` · ${hata} hata` : ""}.`);
    });
  }

  // Oto Sorgula sırasında dosya-başına masraf çekimi YOK (kaynak tek ekran: Ödeme İşlemlerim) — iskelet dursun.
  async function masrafTopla(dosyaId, rec) { /* kaynak = Ödeme İşlemlerim akışı (masrafTara) */ }

  // ── evrak listesi + safahat (uç aileleri; çalışan uç öğrenilir) ────────────
  function evrakItems(json) {
    let items = [];
    if (Array.isArray(json)) items = Array.isArray(json[0]) ? json[0] : json;
    else if (json && typeof json === "object") {
      items = json.evraklar || json.list || json.data || json.evrakListesi || json.content || json.rows || [];
      if ((!items || !items.length) && json.tumEvraklar && typeof json.tumEvraklar === "object") items = Object.values(json.tumEvraklar).flat();
    }
    return Array.isArray(items) ? items : [];
  }
  function parseEvrak(json) {
    const items = evrakItems(json);
    if (!items.length) return [];
    const k0 = Object.keys(items[0] || {});
    if (!k0.some((k) => /evrak|tarih|teblig|belge|konu|aciklama/i.test(k))) return [];
    return items.map((it) => {
      if (!it || typeof it !== "object") return null;
      let tarih = "";
      for (const c of [it.evrakTarihi, it.tarih, it.onaylandigiTarih, it.sistemeGonderildigiTarih, it.evrakGeldigiTarih, it.kayitTarihi, it.islemTarihi]) { const d = detectDate(c); if (d) { tarih = d; break; } }
      if (!tarih) for (const kk of Object.keys(it)) { if (/tebli/i.test(kk)) continue; const d = detectDate(it[kk]); if (d) { tarih = d; break; } }
      let teblig = ""; for (const c of [it.tebligTarihi, it.tebligatTarihi]) { const d = detectDate(c); if (d) { teblig = d; break; } }
      const tur = it.evrakTuru || it.evrakTuruAdi || it.tur || it.belgeTuru || "";
      const aciklama = it.aciklama || it.konu || it.evrakAdi || it.adi || it.baslik || "";
      const evrakId = it.evrakId || it.id || it.evrak_id || it.evrakID || it.siraNo || "";
      return { evrakId, tarih, tur: String(tur), aciklama: String(aciklama), tebligTarihi: teblig };
    }).filter(Boolean);
  }
  const EVRAK_ENDPOINTS = [
    (id) => ["/list_dosya_evraklar.ajx", { dosyaId: id, pageNumber: 1 }],
    (id) => ["/listDosyaEvraklarPageTotal.ajx", { dosyaId: id, pageNumber: 1 }],
    (id) => ["/dosya_evrak_listesi_brd.ajx", { dosyaId: id }],
    (id) => ["/dosyaEvrakListesi.ajx", { dosyaId: id }],
    (id) => ["/evrak_listesi_brd.ajx", { dosyaId: id }],
    (id) => ["/evrak_listesi.ajx", { dosyaId: id }],
  ];
  let _evrakEp = null;
  async function evrakListe(dosyaId, rec) {
    const dene = async (f) => { const [url, body] = f(dosyaId); try { const j = await apiPost(url, body); const l = parseEvrak(j); if (l.length) { _evrakEp = f; return l; } } catch (e) {} return null; };
    let list = _evrakEp ? await dene(_evrakEp) : null;
    if (!list) for (const f of EVRAK_ENDPOINTS) { list = await dene(f); if (list) break; await sleep(200); }
    if (list && list.length) {
      rec.evrak = list;
      rec.sonEvrakTarihi = list.map((e) => e.tarih).filter(Boolean).sort().slice(-1)[0] || "";
      const teb = list.map((e) => e.tebligTarihi).filter(Boolean).sort()[0];
      if (teb) rec.tebligTarihi = teb;
    }
  }
  function parseSafahat(json) {
    let items = Array.isArray(json) ? (Array.isArray(json[0]) ? json[0] : json)
      : (json && typeof json === "object" ? (json.safahat || json.safahatlar || json.list || json.data || json.rows || json.content || []) : []);
    if (!Array.isArray(items)) items = [];
    return items.map((it) => {
      if (!it || typeof it !== "object") return null;
      let tarih = "";
      for (const c of [it.islemTarihi, it.safahatTarihi, it.tarih, it.kayitTarihi]) { const d = detectDate(c); if (d) { tarih = d; break; } }
      if (!tarih) for (const kk of Object.keys(it)) { const d = detectDate(it[kk]); if (d) { tarih = d; break; } }
      const islem = it.islem || it.safahat || it.islemTuru || it.aciklama || it.tur || it.durum || it.konu || "";
      return islem ? { tarih, islem: String(islem) } : null;
    }).filter(Boolean);
  }
  const SAFAHAT_ENDPOINTS = [
    (id) => ["/dosya_safahat_bilgileri_brd.ajx", { dosyaId: id }],
    (id) => ["/dosyaSafahatBilgileri.ajx", { dosyaId: id }],
    (id) => ["/dosya_safahat_brd.ajx", { dosyaId: id }],
    (id) => ["/safahat_bilgileri_brd.ajx", { dosyaId: id }],
    (id) => ["/dosyaSafahat.ajx", { dosyaId: id }],
  ];
  let _safahatEp = null, _safahatDene = true, _safahatFail = 0;
  async function safahat(dosyaId, rec) {
    if (!_safahatDene) return;
    const dene = async (f) => { const [url, body] = f(dosyaId); try { const j = await apiPost(url, body); const l = parseSafahat(j); if (l.length) { _safahatEp = f; return l; } } catch (e) {} return null; };
    let list = _safahatEp ? await dene(_safahatEp) : null;
    if (!list) for (const f of SAFAHAT_ENDPOINTS) { list = await dene(f); if (list) break; await sleep(150); }
    if (list && list.length) { rec.safahat = list; rec.safahatSon = list.map((s) => s.tarih).filter(Boolean).sort().slice(-1)[0] || ""; }
    else if (!_safahatEp && ++_safahatFail >= 4) _safahatDene = false;
  }

  // ═══════════════ EŞLEŞTİRME ÇEKİRDEĞİ — (daire + esas) kimliği ═══════════════
  // Tenant unvanından taraf-eşleştirme regex'i: "Zurich Sigorta A.Ş." → /zurich/i (+ sigorta varsa /zurich\s*si?gorta/i)
  function unvanRegex(unvan) {
    const kelimeler = norm(unvan).split(" ").filter(Boolean);
    if (!kelimeler.length) return null;
    const q = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    if (kelimeler[1] && /si?gorta/.test(kelimeler[1])) return new RegExp(q(kelimeler[0]) + "\\s*si?gorta", "i");
    return new RegExp("(^|\\s)" + q(kelimeler[0]) + "(\\s|$)", "i");
  }

  /**
   * TARAF DOĞRULAMASI — büroda ALEYHE dosyalar da var (tenant borçlu/davalı taraf): tek aday bile
   * dönse, ALACAKLISI tenant unvanı değilse yazım YAPILMAZ → TARAF_UYUSMAZ raporu. Yanlış (aleyhe)
   * dosyaya olay/masraf yazmak, hiç yazmamaktan çok daha tehlikeli.
   */
  async function tarafDogrula(h, aday) {
    if (!h.unvanRe) return { ok: true, not: "alacaklı unvanı programda tanımsız — taraf doğrulaması ATLANDI (Şirket Bilgileri'nden girin)" };
    let taraf;
    try { await sleep(300); taraf = await taraflar(aday.dosyaId); } catch (e) { return { ok: true, not: "taraf sorgusu başarısız (" + e.message + ") — doğrulamasız eşleşme, KONTROL ET" }; }
    const alacakliMi = taraf.some((t) => /alacakl|davac/i.test(t.rol) && h.unvanRe.test(t.ad));
    if (alacakliMi) return { ok: true };
    const bizBorcluMu = taraf.some((t) => /bor[çc]lu|daval/i.test(t.rol) && h.unvanRe.test(t.ad));
    const ozet = taraf.slice(0, 6).map((t) => `${t.rol}: ${t.ad}`).join(" | ");
    return { ok: false, not: (bizBorcluMu ? "şirket bu dosyada BORÇLU/DAVALI (aleyhe dosya!) — " : "alacaklı şirket değil — ") + ozet };
  }

  /**
   * Hedefi UYAP'ta çöz. hedef = { id, esasNo, yil, sira, daire, unvanRe }
   * Dönüş: { eslesme, not, secilen?, adaylar? } — eslesme: OK|DAIRE_EKSIK|DAIRE_COZULEMEDI|BULUNAMADI|BASKA_DAIRE|COKLU_BELIRSIZ|TARAF_UYUSMAZ
   */
  async function hedefEslestir(h, birimler) {
    if (!h.daire) {
      // Daire bilinmiyorsa yine de genel arama yap — tek aday çıkarsa TARAF DOĞRULAMASIYLA kullan
      const genel = await dosyaAra(h.yil, h.sira, null);
      if (genel.length === 1) {
        const td = await tarafDogrula(h, genel[0]);
        if (!td.ok) return { eslesme: "TARAF_UYUSMAZ", not: `genel aramada tek aday (${genel[0].birimAdi}) ama ${td.not}` };
        return { eslesme: "OK", not: "daire programda boştu — genel aramada tek aday: " + genel[0].birimAdi + (td.not ? " · " + td.not : ""), secilen: genel[0] };
      }
      if (!genel.length) return { eslesme: "DAIRE_EKSIK", not: "programda icra dairesi boş; genel aramada da dosya yok" };
      return coklustanSec(h, genel, "daire programda boş — " + genel.length + " aday");
    }
    const birim = birimCoz(h.daire, birimler);
    if (!birim) {
      return { eslesme: "DAIRE_COZULEMEDI", not: `"${h.daire}" UYAP daire listesinde eşleşmedi (avukat kartının erişebildiği ${birimler.length} birim tarandı)` };
    }
    // Kimlik sorgusu: BU dairede bu esas no. TEK aday bile olsa taraf doğrulanır (aleyhe dosya kemeri).
    const adaylar = await dosyaAra(h.yil, h.sira, birim.birimId);
    if (adaylar.length === 1) {
      const td = await tarafDogrula(h, adaylar[0]);
      if (!td.ok) return { eslesme: "TARAF_UYUSMAZ", not: `${h.daire} ${h.esasNo}: ${td.not}` };
      return { eslesme: "OK", secilen: adaylar[0], not: td.not || "" };
    }
    if (adaylar.length > 1) return coklustanSec(h, adaylar, `aynı dairede ${adaylar.length} kayıt`);
    // Dairede yok → genel aramayla NEREDE olduğunu bul (altın değerinde teşhis bilgisi)
    await sleep(300);
    const genel = await dosyaAra(h.yil, h.sira, null);
    if (!genel.length) return { eslesme: "BULUNAMADI", not: `${h.esasNo} hiçbir dairede bulunamadı (bu avukat kartıyla görünmüyor olabilir)` };
    const nerede = genel.map((c) => `${c.birimAdi || "?"} (${durumTahmin(c.durumKod, c.durum)})`).join(" | ");
    return { eslesme: "BASKA_DAIRE", not: `"${h.daire}"de yok; şurada var: ${nerede} — programdaki daire kaydını düzeltin`, adaylar: genel };
  }

  // Çoklu adaydan seçim: alacaklısı TENANT olan (100p) > açık (10p) > daire eşleşen (1p).
  // Net kazanan yoksa (unvan hiçbirinde alacaklı değilse) COKLU_BELIRSIZ — YANLIŞ dosyaya yazmaktansa sor.
  async function coklustanSec(h, adaylar, bag) {
    const inceleme = [];
    for (const c of adaylar) {
      await sleep(350);
      let alacakliMi = false, taraf = [];
      try { taraf = await taraflar(c.dosyaId); alacakliMi = !!(h.unvanRe && taraf.some((t) => /alacakl/i.test(t.rol) && h.unvanRe.test(t.ad))); } catch (e) {}
      inceleme.push(Object.assign({ alacakliMi, durTah: durumTahmin(c.durumKod, c.durum), taraf }, c));
    }
    const puan = (c) => (c.alacakliMi ? 100 : 0) + (c.durTah === "AÇIK" ? 10 : 0) + (h.daire && norm(c.birimAdi).includes(norm(h.daire).split(" ")[0]) ? 1 : 0);
    inceleme.sort((a, b) => puan(b) - puan(a));
    const kazanan = inceleme[0];
    const liste = inceleme.map((c) => `${c.birimAdi || "?"}·${c.durTah}${c.alacakliMi ? "·ALACAKLI✓" : ""}`).join(" | ");
    // Net kazanan: alacaklı-eşleşen TEK dosya → OK. Alacaklı-eşleşen birden çoksa ya da hiç yoksa → BELİRSİZ.
    const alacakliOlanlar = inceleme.filter((c) => c.alacakliMi);
    if (alacakliOlanlar.length === 1) return { eslesme: "OK", secilen: alacakliOlanlar[0], not: `${bag} → alacaklı eşleşmesiyle seçildi [${liste}]` };
    if (alacakliOlanlar.length > 1) {
      const acik = alacakliOlanlar.filter((c) => c.durTah === "AÇIK");
      if (acik.length === 1) return { eslesme: "OK", secilen: acik[0], not: `${bag} → alacaklı+AÇIK seçildi [${liste}]` };
    }
    return { eslesme: "COKLU_BELIRSIZ", not: `${bag}; net alacaklı eşleşmesi yok — elle seçin: [${liste}]`, adaylar: inceleme, secilen: kazanan };
  }

  // ═══════════════ olay türetme + senkron gövdesi ═══════════════
  function tipFromMetin(s) {
    const t = String(s || "").toLowerCase();
    if (/itiraz/.test(t)) return "ITIRAZ";
    if (/haciz/.test(t)) return "HACIZ";
    if (/kesinleş|kesinles/.test(t)) return "KESINLESTI";
    if (/tahsil|reddiyat|makbuz|ödeme|odeme/.test(t)) return "TAHSILAT";
    if (/tebli|mazbata/.test(t)) return "TEBLIG";
    return null;
  }
  function olaylarTuret(rec) {
    const ol = [];
    const ekle = (tip, tarih, aciklama) => { if (tip) ol.push({ tip, tarih: tarih || null, aciklama: String(aciklama || "").slice(0, 200) }); };
    if (rec.tebligTarihi) ekle("TEBLIG", rec.tebligTarihi, "Tebliğ (UYAP)");
    for (const ev of rec.evrak || []) {
      const tip = tipFromMetin(ev.tur || ev.aciklama);
      if (tip && (ev.tarih || ev.tebligTarihi)) ekle(tip, ev.tarih || ev.tebligTarihi, ev.tur || ev.aciklama);
    }
    for (const s of rec.safahat || []) {
      const tip = tipFromMetin(s.islem);
      if (tip && s.tarih) ekle(tip, s.tarih, s.islem);
    }
    // Aşama/durum metni "itiraz" diyorsa ve tarihli itiraz olayı yoksa → STABİL tarihe bağla (flood önlemi)
    if (!ol.some((o) => o.tip === "ITIRAZ") && (/itiraz/i.test(String(rec.asama || "")) || /itiraz/i.test(String(rec.durum || "")))) {
      const t = rec.safahatSon || rec.sonEvrakTarihi || rec.tebligTarihi || "";
      if (t) ekle("ITIRAZ", t, "Takibe itiraz (UYAP aşama)");
    }
    return ol;
  }

  function senkronGovde(h, rec, eslesmeSonuc) {
    const govde = {
      dosyaId: h.id, // program kimliği — kesin eşleşme (v1)
      icraDosyaNo: h.esasNo,
      eslesme: { durum: eslesmeSonuc.eslesme, not: (eslesmeSonuc.not || "").slice(0, 900) || null },
    };
    if (rec) {
      govde.durum = rec.durumTahmin || rec.durum || null;
      govde.olaylar = olaylarTuret(rec);
      govde.hesap = {
        durumMetni: rec.durum || null, birim: rec.birim || null,
        toplamAlacak: rec.toplamAlacak ?? null, asilAlacak: rec.asilAlacak ?? null,
        islemisFaiz: rec.islemisFaiz ?? null, tahsilat: rec.tahsilat ?? null,
        bakiye: rec.bakiye ?? null, vekalet: rec.vekalet ?? null,
        sonEvrakTarihi: rec.sonEvrakTarihi || null, evrakSayisi: (rec.evrak && rec.evrak.length) || 0,
        asama: rec.asama || null, safahatSayisi: (rec.safahat && rec.safahat.length) || 0,
        uyapAcilis: rec.acilis || null,
      };
      if (rec.masrafKalemleri && rec.masrafKalemleri.length) govde.masraflar = rec.masrafKalemleri;
    }
    return govde;
  }

  // ═══════════════ evrak programa yükleme (dedup: evrakId ilk-20 + sunucu manifesti) ═══════════════
  async function fetchB64(url) {
    try {
      const resp = await fetch(url, { credentials: "include" });
      if (!resp.ok) return null;
      let ct = (resp.headers.get("content-type") || "").toLowerCase().split(";")[0].trim();
      const buf = await resp.arrayBuffer();
      if (!buf.byteLength || buf.byteLength > 3200000) return null;
      const bytes = new Uint8Array(buf);
      const sig = String.fromCharCode(bytes[0] || 0, bytes[1] || 0, bytes[2] || 0, bytes[3] || 0);
      if (/html|text\/|application\/json/.test(ct) || sig.slice(0, 2) === "<h" || sig.slice(0, 4).toLowerCase() === "<!do" || sig.slice(0, 2) === "<!") return null;
      if (!ct || ct === "application/octet-stream") {
        ct = sig === "%PDF" ? "application/pdf" : (sig.slice(0, 2) === "II" || sig.slice(0, 2) === "MM") ? "image/tiff"
          : (bytes[0] === 0xFF && bytes[1] === 0xD8) ? "image/jpeg" : sig === "\x89PNG" ? "image/png" : "application/octet-stream";
      }
      let bin = ""; for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
      return { b64: btoa(bin), mime: ct };
    } catch (e) { return null; }
  }
  const mimeExt = (m) => { m = String(m || ""); return m.includes("pdf") ? ".pdf" : m.includes("tiff") ? ".tif" : m.includes("jpeg") ? ".jpg" : m.includes("png") ? ".png" : ".pdf"; };
  const PDF_ENDPOINTS = ["/main/icra/modules/evrak/view_document_brd.uyap", "/main/icra/modules/evrak/download_document_brd.uyap"];
  let _pdfEp = null;

  async function evrakYukle(h, rec) {
    if (!rec.uyapDosyaId || !Array.isArray(rec.evrak) || !rec.evrak.length) return 0;
    const o = await st(["gonderilenEvrak"]);
    const gond = o.gonderilenEvrak || {};
    let sunucuOnek = new Set();
    try {
      const mf = await sendBg({ type: "RUCU_EVRAK_MANIFEST", token: h.token, icraDosyaNo: h.esasNo });
      if (mf && mf.ok && mf.data && mf.data.ok && Array.isArray(mf.data.onekler)) sunucuOnek = new Set(mf.data.onekler);
    } catch (e) {}
    const did = String(rec.uyapDosyaId).replace(/"/g, "").trim();
    let n = 0;
    for (const ev of rec.evrak) {
      if (!ev.evrakId) continue;
      const eid = String(ev.evrakId).replace(/"/g, "").trim();
      const kimlik = eid.slice(0, 20);
      const key = h.esasNo + ":" + kimlik;
      if (gond[key] || sunucuOnek.has(kimlik)) { gond[key] = true; continue; }
      let res = null;
      const eps = _pdfEp ? [_pdfEp].concat(PDF_ENDPOINTS.filter((e) => e !== _pdfEp)) : PDF_ENDPOINTS.slice();
      for (const ep of eps) {
        res = await fetchB64(location.origin + ep + "?dosyaId=" + encodeURIComponent(did) + "&evrakId=" + encodeURIComponent(eid));
        if (res) { _pdfEp = ep; break; }
      }
      if (!res) continue;
      const ad = ((ev.tur || ev.aciklama || "evrak") + " " + (ev.tarih || "")).trim().slice(0, 120) + mimeExt(res.mime);
      const r = await sendBg({ type: "RUCU_EVRAK", token: h.token, body: { icraDosyaNo: h.esasNo, dosyaId: h.id, uyapEvrakId: eid, dosyaAdi: ad, tur: ev.tur || "", contentBase64: res.b64, mime: res.mime } });
      if (r.ok && r.data && r.data.ok) { gond[key] = true; n++; }
      await sleep(400);
    }
    await stSet({ gonderilenEvrak: gond });
    return n;
  }

  // ═══════════════ ANA AKIŞ — ÇOKLU ANAHTAR (Ray + Zurich tek kurulumda) ═══════════════
  // Her tenant'ın kendi senkron anahtarı var; eklenti HEPSİNİ saklar ve her turda sırayla
  // hepsinin hedeflerini çekip kendi anahtarıyla geri yazar. Anahtar değiş-tokuşu bitti.
  async function anahtarlar() {
    const r = await sendBg({ type: "RUCU_TOKENLAR" });
    return (r && r.tokenlar) || [];
  }

  let _calisiyor = false;
  async function senkronCalistir(gorunur) {
    if (_calisiyor) { if (gorunur) flash("Zaten çalışıyor…"); return; }
    _calisiyor = true;
    try {
      const tokenlar = await anahtarlar();
      if (!tokenlar.length) { if (gorunur) flash("Senkron anahtarı yok — ⚙ Ayar'dan gir."); return; }

      // tüm tenant'ların hedeflerini topla (her hedef kendi token'ını taşır)
      const hedefler = [];
      for (const token of tokenlar) {
        const hr = await sendBg({ type: "RUCU_HEDEFLER", token });
        if (!hr.ok || !hr.data || !hr.data.ok) { if (gorunur) ekleSatir(`⚠ bir anahtar hedef veremedi: ${hr.error || hr.status || "?"}`); continue; }
        for (const x of hr.data.hedefler || []) {
          if (!x.icraDosyaNo) continue;
          const esas = extractEsas(x.icraDosyaNo); const m = esas.match(/^(\d{4})\/(\d+)$/);
          if (m) hedefler.push({ id: x.id, esasNo: esas, yil: m[1], sira: m[2], daire: tr(x.daire || ""), unvanRe: unvanRegex(x.alacakliUnvan || ""), token });
        }
      }
      if (!hedefler.length) { if (gorunur) flash("Senkron bekleyen dosya yok — her şey taze. 🎉"); _seritIlerleme = null; seritGuncelle(); return; }

      if (gorunur) durumYaz(`▶ ${hedefler.length} hedef (daire+esas) kimliğiyle sorgulanıyor… (${tokenlar.length} şirket)`);
      const birimler = await birimlerYukle();
      if (!birimler.length) { if (gorunur) flash("UYAP daire listesi alınamadı — oturum düşmüş olabilir, sayfayı yenileyin."); return; }

      let ok = 0, sorunlu = 0;
      for (let i = 0; i < hedefler.length; i++) {
        const h = hedefler[i];
        _seritIlerleme = `${i + 1}/${hedefler.length} · ${h.esasNo}`; seritGuncelle();
        const satir = ekleSatir(`(${i + 1}/${hedefler.length}) ${h.esasNo} — ${h.daire || "daire?"}…`);
        try {
          const sonuc = await hedefEslestir(h, birimler);
          if (sonuc.eslesme !== "OK") {
            sorunlu++;
            // Bulunamayan/belirsiz/TARAF_UYUSMAZ dosya da programa RAPORLANIR — kör nokta kalmaz
            await sendBg({ type: "RUCU_SENKRON", token: h.token, body: senkronGovde(h, null, sonuc) });
            satirYaz(satir, `⚠ <b>${esc(h.esasNo)}</b>: ${esc(sonuc.eslesme)} — ${esc(sonuc.not || "")}`);
            await sleep(800); continue;
          }
          const f = sonuc.secilen;
          const rec = { uyapDosyaId: f.dosyaId, durum: f.durum || "", durumKod: f.durumKod, birim: f.birimAdi || h.daire, acilis: f.acilis || "" };
          satirYaz(satir, `⏳ <b>${esc(h.esasNo)}</b> (${esc(rec.birim)}): detay çekiliyor…`);
          await sleep(350); await ayrinti(f.dosyaId, rec);
          await sleep(350); await hesap(f.dosyaId, rec);
          await sleep(350); await evrakListe(f.dosyaId, rec);
          await sleep(350); await safahat(f.dosyaId, rec);
          rec.durumTahmin = durumTahmin(rec.durumKod, rec.durum);
          const sr = await sendBg({ type: "RUCU_SENKRON", token: h.token, body: senkronGovde(h, rec, sonuc) });
          let evN = 0;
          if (rec.evrak && rec.evrak.length) evN = await evrakYukle(h, rec);
          if (sr.ok && sr.data && sr.data.ok) {
            ok++;
            const para = rec.bakiye != null ? ` · bakiye ${fmtTL(rec.bakiye)}` : "";
            satirYaz(satir, `✅ <b>${esc(h.esasNo)}</b> (${esc(rec.birim)}): ${esc(rec.durumTahmin)}${para}${evN ? ` · 📤 ${evN} yeni evrak` : ""}${sonuc.not ? ` <span class="rucu-mut">${esc(sonuc.not)}</span>` : ""}`);
          } else {
            sorunlu++;
            satirYaz(satir, `❌ <b>${esc(h.esasNo)}</b>: program yazımı reddetti (${esc(String((sr.data && (sr.data.error || sr.data.raw)) || sr.error || sr.status))})`);
          }
        } catch (e) {
          sorunlu++;
          try { await sendBg({ type: "RUCU_SENKRON", token: h.token, body: senkronGovde(h, null, { eslesme: "HATA", not: e.message }) }); } catch (e2) {}
          satirYaz(satir, `❌ <b>${esc(h.esasNo)}</b>: ${esc(e.message || "hata")}`);
        }
        await sleep(1200); // UYAP'a nazik
      }
      await stSet({ sonOtoSync: Date.now(), sonRapor: { t: new Date().toISOString(), ok, sorunlu, toplam: hedefler.length } });
      if (gorunur) flash(`Bitti: ${ok} senkron, ${sorunlu} sorunlu (sorunlular da programa raporlandı).`);
    } finally { _calisiyor = false; _seritIlerleme = null; seritGuncelle(); }
  }

  async function otoSenkron() {
    const tokenlar = await anahtarlar();
    if (!tokenlar.length) return;
    const o = await st(["sonOtoSync"]);
    if (Date.now() - (o.sonOtoSync || 0) < 25 * 60000) return; // throttle
    await senkronCalistir(false);
  }

  // ═══════════════ mini panel (durum + tetik + ayar) + CANLILIK ŞERİDİ ═══════════════
  const CSS = `
  #rucu-serit{position:fixed;left:0;right:0;bottom:0;z-index:2147482999;height:26px;display:flex;align-items:center;gap:8px;padding:0 12px;font:12px system-ui;color:#fff;cursor:pointer;user-select:none;box-shadow:0 -2px 8px rgba(0,0,0,.15)}
  #rucu-serit.s-ok{background:#0f766e}
  #rucu-serit.s-run{background:#b45309}
  #rucu-serit.s-err{background:#b91c1c}
  #rucu-serit.s-idle{background:#475569}
  #rucu-serit .rs-dot{width:8px;height:8px;border-radius:50%;background:#fff;flex:none}
  #rucu-serit.s-run .rs-dot{animation:rucupulse 1s infinite}
  @keyframes rucupulse{0%,100%{opacity:1}50%{opacity:.3}}
  #rucu-serit .rs-txt{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  #rucu-fab{position:fixed;right:14px;bottom:38px;z-index:2147483000;width:46px;height:46px;border-radius:50%;background:#0f766e;color:#fff;font:700 17px/46px system-ui;text-align:center;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.25);user-select:none}
  #rucu-panel{position:fixed;right:14px;bottom:92px;z-index:2147483000;width:460px;max-height:70vh;overflow:auto;background:#fff;border:1px solid #d5dbe3;border-radius:12px;box-shadow:0 10px 34px rgba(0,0,0,.22);font:13px system-ui;display:none;color:#111}
  #rucu-panel.open{display:block}
  .rucu-hd{display:flex;align-items:center;gap:8px;padding:10px 12px;border-bottom:1px solid #eef1f4;font-weight:700}
  .rucu-hd .v{font-weight:400;color:#889;font-size:11px}
  .rucu-bd{padding:10px 12px}
  .rucu-row{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px}
  .rucu-btn{border:0;border-radius:8px;background:#0f766e;color:#fff;font:600 12.5px system-ui;padding:7px 12px;cursor:pointer}
  .rucu-btn.sec{background:#eef1f4;color:#111}
  .rucu-mut{color:#66707c;font-size:11.5px}
  .rucu-log{border-top:1px dashed #e3e7ec;margin-top:6px;padding-top:6px}
  .rucu-log>div{padding:3px 0;border-bottom:1px solid #f2f4f7;font-size:12px}
  .rucu-flash{background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:7px 10px;margin-bottom:8px;font-size:12.5px}`;
  let panel = null, logEl = null, durumEl = null, serit = null, seritTxt = null;
  let _seritIlerleme = null; // çalışırken "3/12 · 2026/4186" gibi canlı metin

  // ── canlılık şeridi: "program bağlı mı, en son ne zaman çalıştı, sıradaki oto ne zaman" tek bakışta ──
  async function seritGuncelle() {
    if (!serit) return;
    if (_seritIlerleme) { serit.className = "s-run"; seritTxt.innerHTML = `Rücu Takip · senkron çalışıyor — ${esc(_seritIlerleme)}`; return; }
    const o = await st(["senkronToken", "senkronTokenlar", "sonOtoSync", "sonRapor"]);
    const anahtarSayisi = (Array.isArray(o.senkronTokenlar) && o.senkronTokenlar.length) ? o.senkronTokenlar.length : (o.senkronToken ? 1 : 0);
    if (!anahtarSayisi) { serit.className = "s-err"; seritTxt.innerHTML = `Rücu Takip <b>bağlı değil</b> — senkron anahtarı girilmedi · tıkla → ⚙ Ayar`; return; }
    const son = o.sonOtoSync || 0;
    const r = o.sonRapor;
    const dkOnce = son ? Math.round((Date.now() - son) / 60000) : null;
    const siradaki = son ? Math.max(0, 30 - (dkOnce ?? 0)) : 0;
    const rapor = r ? ` · ${r.ok} dosya ✓${r.sorunlu ? ` · <b>${r.sorunlu} sorunlu</b>` : ""}` : "";
    const sirket = anahtarSayisi > 1 ? ` · ${anahtarSayisi} şirket` : "";
    if (dkOnce == null) { serit.className = "s-idle"; seritTxt.innerHTML = `Rücu Takip hazır${sirket} — henüz senkron koşmadı · birazdan otomatik başlar (ya da tıkla → ▶)`; return; }
    serit.className = dkOnce > 45 ? "s-idle" : "s-ok";
    seritTxt.innerHTML = `Rücu Takip aktif${sirket} · son senkron <b>${dkOnce} dk önce</b>${rapor} · sıradaki oto ~${siradaki} dk`;
  }

  function buildUi() {
    if (panel || !document.body) return;
    const style = document.createElement("style"); style.textContent = CSS; document.head.appendChild(style);
    // alt şerit — otomasyonun YAŞADIĞINI gösterir; tıklayınca panel açılır
    serit = document.createElement("div"); serit.id = "rucu-serit"; serit.className = "s-idle";
    serit.innerHTML = `<span class="rs-dot"></span><span class="rs-txt">Rücu Takip yükleniyor…</span>`;
    seritTxt = serit.querySelector(".rs-txt");
    serit.addEventListener("click", togglePanel);
    document.body.appendChild(serit);
    seritGuncelle();
    setInterval(seritGuncelle, 30000); // 30 sn'de bir tazele ("X dk önce" güncel kalsın)
    const fab = document.createElement("div"); fab.id = "rucu-fab"; fab.textContent = "R"; fab.title = "Rücu Takip";
    fab.addEventListener("click", togglePanel);
    document.body.appendChild(fab);
    panel = document.createElement("div"); panel.id = "rucu-panel";
    panel.innerHTML = `
      <div class="rucu-hd">Rücu Takip · UYAP Senkron <span class="v">v1.1.0 · (daire+esas) kimlikli</span></div>
      <div class="rucu-bd">
        <div class="rucu-row">
          <button class="rucu-btn" id="rucu-run">▶ Şimdi Senkronla</button>
          <button class="rucu-btn" id="rucu-masraf" style="background:#b45309">💰 Masraf Tara</button>
          <button class="rucu-btn sec" id="rucu-cfg">⚙ Ayar</button>
          <button class="rucu-btn sec" id="rucu-diag">🧪 Tanı</button>
        </div>
        <div id="rucu-durum" class="rucu-mut">▶ hedefleri (icra dairesi + esas no) kimliğiyle sorgular; bulamadığını da programa <b>raporlar</b>. 30 dk'da bir otomatik.<br>💰 için: UYAP menü → <b>Ödeme İşlemlerim</b> → tarih aralığını seçip listele → sonra 💰'ya bas.</div>
        <div class="rucu-log" id="rucu-log"></div>
      </div>`;
    document.body.appendChild(panel);
    logEl = panel.querySelector("#rucu-log");
    durumEl = panel.querySelector("#rucu-durum");
    panel.querySelector("#rucu-run").addEventListener("click", () => senkronCalistir(true));
    panel.querySelector("#rucu-masraf").addEventListener("click", masrafTara);
    panel.querySelector("#rucu-cfg").addEventListener("click", ayarSor);
    panel.querySelector("#rucu-diag").addEventListener("click", tani);
  }
  function togglePanel() { buildUi(); panel.classList.toggle("open"); }
  function flash(msg) { buildUi(); const d = document.createElement("div"); d.className = "rucu-flash"; d.textContent = msg; panel.querySelector(".rucu-bd").prepend(d); setTimeout(() => d.remove(), 8000); }
  function durumYaz(html) { buildUi(); durumEl.innerHTML = html; }
  function ekleSatir(text) { buildUi(); const d = document.createElement("div"); d.textContent = text; logEl.prepend(d); return d; }
  function satirYaz(el, html) { el.innerHTML = html; }

  async function ayarSor() {
    const cur = await st(["programBase", "senkronTokenlar", "senkronToken"]);
    const base = window.prompt("Program adresi:", cur.programBase || "https://konsrucu.vercel.app");
    if (base == null) return;
    const eskiListe = Array.isArray(cur.senkronTokenlar) && cur.senkronTokenlar.length ? cur.senkronTokenlar : (cur.senkronToken ? [cur.senkronToken] : []);
    const girdi = window.prompt(
      "Senkron anahtarları — HER ŞİRKET İÇİN BİR TANE, virgülle ayır (Ray'inki + Zurich'inki).\nHer şirketin anahtarı kendi Şirket Bilgileri ekranından üretilir:",
      eskiListe.join(", ")
    );
    if (girdi == null) return;
    const liste = girdi.split(",").map((x) => x.trim()).filter(Boolean);
    await stSet({ programBase: base.trim().replace(/\/+$/, ""), senkronTokenlar: liste, senkronToken: liste[0] || "" });
    flash(`Ayar kaydedildi — ${liste.length} şirket anahtarı tanımlı.`);
    seritGuncelle();
  }

  async function tani() {
    durumYaz("Tanı çalışıyor…");
    const parca = [];
    try { const b = await birimlerYukle(); parca.push(`UYAP daire listesi: <b>${b.length}</b> birim (oturum ✓)`); }
    catch (e) { parca.push(`UYAP daire listesi: ❌ ${esc(e.message)} — oturum düşmüş olabilir`); }
    const tokenlar = await anahtarlar();
    if (!tokenlar.length) parca.push("Program anahtarı: ❌ tanımsız — ⚙ Ayar");
    for (let i = 0; i < tokenlar.length; i++) {
      const hr = await sendBg({ type: "RUCU_HEDEFLER", token: tokenlar[i] });
      if (hr.ok && hr.data && hr.data.ok) parca.push(`Şirket ${i + 1} ✓ — senkron bekleyen: <b>${(hr.data.hedefler || []).length}</b> / aktif ${hr.data.aktifToplam ?? "?"}`);
      else parca.push(`Şirket ${i + 1}: ❌ ${esc(String(hr.error || (hr.data && hr.data.error) || hr.status))} (anahtar geçersiz olabilir)`);
    }
    const o = await st(["sonRapor"]);
    if (o.sonRapor) parca.push(`Son koşu: ${esc(o.sonRapor.t)} → ${o.sonRapor.ok} senkron, ${o.sonRapor.sorunlu} sorunlu / ${o.sonRapor.toplam}`);
    durumYaz(parca.join("<br>"));
  }

  // mesajlar: ikon tıklaması + background poll
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    if (msg.type === "RUCU_TOGGLE") togglePanel();
    else if (msg.type === "RUCU_AUTO_SYNC") otoSenkron();
  });
  // sayfa yüklenince (yapılandırılmışsa, 25 dk throttle) otomatik senkron
  st(["senkronToken", "senkronTokenlar", "sonOtoSync"]).then((o) => {
    const var_ = (Array.isArray(o.senkronTokenlar) && o.senkronTokenlar.length) || o.senkronToken;
    if (var_ && Date.now() - (o.sonOtoSync || 0) > 25 * 60000) setTimeout(otoSenkron, 20000);
  });

  if (document.body) buildUi();
  else document.addEventListener("DOMContentLoaded", buildUi);
})();
