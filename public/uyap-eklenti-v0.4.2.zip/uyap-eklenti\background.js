// Eklenti ikonuna tıklanınca aktif sekmedeki panele "aç/kapat" mesajı gönderir.
chrome.action.onClicked.addListener((tab) => {
  if (!tab || !tab.id) return;
  chrome.tabs.sendMessage(tab.id, { type: "RUCU_TOGGLE" }).catch(() => {
    // İçerik scripti yüklü değilse (uyap dışı sayfa) sessiz geç.
  });
});

// Evrak PDF indirme — content script'ten gelen istekle (tarayıcı çereziyle indirir)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "RUCU_DOWNLOAD") {
    chrome.downloads.download(
      { url: msg.url, filename: msg.filename, conflictAction: "uniquify", saveAs: false },
      (id) => {
        const err = chrome.runtime.lastError;
        sendResponse({ ok: !err && id != null, id: id || null, error: err ? err.message : null });
      }
    );
    return true; // async sendResponse
  }
});
