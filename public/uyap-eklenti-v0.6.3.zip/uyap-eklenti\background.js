// Eklenti ikonuna tıklanınca aktif sekmedeki panele "aç/kapat" mesajı gönderir.
chrome.action.onClicked.addListener((tab) => {
  if (!tab || !tab.id) return;
  chrome.tabs.sendMessage(tab.id, { type: "RUCU_TOGGLE" }).catch(() => {
    // İçerik scripti yüklü değilse (uyap dışı sayfa) sessiz geç.
  });
});

// Evrak PDF indirme — content script'ten gelen istekle (tarayıcı çereziyle indirir)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "RUCU_DOWNLOAD") {
    chrome.downloads.download(
      { url: msg.url, filename: msg.filename, conflictAction: "uniquify", saveAs: false },
      (id) => {
        const err = chrome.runtime.lastError;
        sendResponse({ ok: !err && id != null, id: id || null, error: err ? err.message : null });
      }
    );
    return true; // async sendResponse
  }
});

// ───────── Rücu Takip programı senkronu (Bearer = senkron anahtarı) ─────────
const PROGRAM_BASE_DEFAULT = "https://konsrucu.vercel.app";

function programCfg() {
  return new Promise((res) =>
    chrome.storage.local.get(["programBase", "senkronToken"], (o) =>
      res({ base: String((o && o.programBase) || PROGRAM_BASE_DEFAULT).replace(/\/+$/, ""), token: (o && o.senkronToken) || "" })
    )
  );
}

async function programFetch(path, opts) {
  const { base, token } = await programCfg();
  if (!token) return { ok: false, error: "Senkron anahtarı yok — Program Ayarı'ndan gir." };
  try {
    const resp = await fetch(base + path, {
      method: (opts && opts.method) || "GET",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
      body: opts && opts.body ? opts.body : undefined,
    });
    const txt = await resp.text();
    let data; try { data = JSON.parse(txt); } catch (e) { data = { raw: txt }; }
    return { ok: resp.ok, status: resp.status, data };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === "RUCU_HEDEFLER") { programFetch("/api/uyap/hedefler", { method: "GET" }).then(sendResponse); return true; }
  if (msg.type === "RUCU_SENKRON") { programFetch("/api/uyap/senkron", { method: "POST", body: JSON.stringify(msg.body || {}) }).then(sendResponse); return true; }
  if (msg.type === "RUCU_EVRAK") { programFetch("/api/uyap/evrak", { method: "POST", body: JSON.stringify(msg.body || {}) }).then(sendResponse); return true; }
});

// Periyodik poll (45 dk) — tarayıcı açıkken; bir UYAP sekmesi varsa otomatik senkron tetikler.
function kurAlarm() { chrome.alarms.create("rucuPoll", { periodInMinutes: 30, delayInMinutes: 1 }); }
chrome.runtime.onInstalled.addListener(kurAlarm);
if (chrome.runtime.onStartup) chrome.runtime.onStartup.addListener(kurAlarm);
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name !== "rucuPoll") return;
  chrome.tabs.query({ url: "*://*.uyap.gov.tr/*" }, (tabs) => {
    const t = tabs && tabs[0];
    if (t && t.id) chrome.tabs.sendMessage(t.id, { type: "RUCU_AUTO_SYNC" }).catch(() => {});
  });
});
