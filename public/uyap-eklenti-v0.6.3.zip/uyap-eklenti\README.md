# Rücu Takip — UYAP Senkron (Chrome Eklentisi)

UYAP Avukat Portalı **Dosya Sorgulama** sonuç tablosunu (DevExtreme grid) okuyup
rücu icra dosyalarının **açık / kapalı** durumunu derler.

> **Sadece okur.** Hiçbir tıklama/sorgu GÖNDERMEZ, dosya **detayına/safahatına GİRMEZ**
> → harç/ücret çıkmaz. Sorguyu sen yaparsın; eklenti ekrandaki sonucu toplar.

---

## 1. Kurulum (tek seferlik)

1. `chrome://extensions` aç → sağ üst **Geliştirici modu** → Aç.
2. **Paketlenmemiş öğe yükle** → klasörü seç:
   `C:\Users\SENFONİ-Berkan\Desktop\Rucu_Takip\uyap-eklenti`
3. (Daha önce yüklediysen: eklentide **↻ yenile** simgesine bas — yeni sürüm gelsin.)

---

## 2. Neden tek tek? (2813 dosya sorunu)

Dosya Sorgulama boş bırakılınca **2813** dosyayı **10'arlı sayfalarla** gösteriyor —
6 rücu dosyan bu ~282 sayfanın içine dağılmış. Hepsini taramak yerine **6 dosyayı
tek tek sorgulayıp biriktiriyoruz.** Sen numarayı girersin (zaten yapıyorsun),
eklenti durumları derleyip eşleştirir.

## 3. Kullanım — ▶ Oto Sorgula (tek tık · API)

Eklenti formu hiç kullanmaz; UYAP'ın **kendi iç API'sini** senin oturum çerezinle
çağırır (eski Ray Sigorta eklentindeki kanıtlanmış yöntem). Form/selectbox/sayfalama yok.

1. UYAP Avukat Portalına **e-imza ile gir** (herhangi bir sayfa açık olsun, ör. Dosya Sorgulama).
2. Sağ alt **⚖ Rücu Tara** → **▶ Oto Sorgula (6 dosya · API)**.
3. Eklenti her hedef için sırayla (insan hızında) şunları çeker:
   - İcra Daireleri listesi (`avukat_mahkemeleri_sorgula.ajx`) → birimId,
   - dosyaId + **durum** (`search_phrase_detayli.ajx`, `dosyaDurumKod:2`=Tümü; durum metni yanıtta gelir),
   - **finansal** (`dosyaAyrintiBilgileri_brd.ajx` + `dosya_hesap_bilgileri.ajx`): asıl alacak, işlemiş faiz, tahsilat, bakiye, vekalet, harç, kalemler,
   - **evrak/safahat** (`list_dosya_evraklar.ajx` vb.): evrak listesi, tebliğ/son işlem tarihleri.
   - **evrak PDF indirme** (📥 seçimine göre): **indirme (sadece liste)** [varsayılan] · **önemli evraklar**
     (ödeme emri, tebligat, haciz, ekspertiz, itiraz, kesinleşme, tahsilat…) · **tüm evraklar**.
     İndirilenler `İndirilenler\rucu-evrak\<dosya no>\` altına PDF olur → belgeler okunabilir/öğrenilebilir.
     Not: evrak LİSTESİ (isim/tür/tarih) modtan bağımsız HER ZAMAN JSON'a kaydedilir.
4. Her dosya için ✅/⚠/❌ satırı; üstte özet **🟢 Açık / 🔴 Kapalı / ⚪ Yok**, tabloda alacak/bakiye/evrak, `📥 N indi`.
5. **⬇ JSON** veya **📋 Kopyala** ile Rücu Takip'e taşı (JSON tüm kalemleri + evrakları içerir).

> Evrak indirme iki halkaya bağlı: (a) evrak LİSTE endpoint'i çalışmalı (evrakId için), (b) PDF endpoint doğru olmalı.
> İndirme tutmazsa eski eklentideki **ağ-dinleme (interception)** parçası eklenip endpoint'ler otomatik keşfedilir.

> Çağrılan endpoint'ler eski Ray Sigorta eklentisinden alındı; **harç çıkmıyor** (kullanıcı teyitli).
> İcra dairesi adları `DAIRE_MAP`'te gömülü (Excel'den). Yeni dosya eklersen dairesini de ekle.

### Yedek yöntem (API çalışmazsa)
Dosyayı UYAP'ta elle **Sorgula** → **➕ Tara & Biriktir** (ekrandaki grid'i okur).

### Düğmeler
- **▶ Oto Sorgula (6 dosya · API)** — 6 rücu dosyasını otomatik sorgular (ana düğme).
- **➕ Tara & Biriktir** — ekrandaki sonucu elle biriktirir (yedek).
- **🔍 Hızlı Tara** — o anki sayfayı gösterir (biriktirmez).
- **🗑 Sıfırla** — biriktirmeyi temizler.
- **⬇ JSON / 📋 Kopyala** — dışa aktar.
- **🎯 Hedef** — dosya listesini düzenle.
- **🧪 DOM Yakala** — sorun olursa çıktıyı bana gönder.

---

## 3.4 Aynı esas no, farklı daire → RAY ALACAKLI olan seçilir (v0.3.0)

Aynı esas no (ör. `2026/798`) **birden fazla icra dairesinde** bulunabilir (biri seninki,
biri başka bir taraf). Eklenti artık sadece numarayla ilk geleni almıyor:

1. Numaranın **tüm dairelerdeki** dosyalarını çeker.
2. Birden fazlaysa her birinin **taraflarına** bakar → **RAY SİGORTA'nın ALACAKLI**
   olduğu dosyayı seçer (rücuda Ray hep alacaklı; yanlış dosyada Ray borçluydu).
3. Hiçbirinde Ray alacaklı değilse **seçmez**, hepsini (daire · açık/kapalı · Ray borçlu?)
   listeler → sen elle bakarsın, **indirme yapmaz** (yanlış dosya inmez).
4. İndirilen evrak klasörüne **daire adı** eklenir: `rucu-evrak\<dosya no> <daire>\`
   (farklı dairelerin aynı numaralı dosyaları karışmaz).

## 3.5 🔭 Keşif (Dava — Tüketici Mahkemesi) · tek seferlik

Dava dosyalarını da çekebilmek için UYAP'ın **Hukuk/Tüketici** yargı-türü ve birim
kodlarını öğrenmemiz gerek (icra için bu kodlar `yargiTuru=2 · yargiBirimi=1101`; dava
için bilinmiyor). **🔭 Keşif (Dava)** düğmesi bunu otomatik bulur:

1. UYAP Avukat Portalına **e-imza ile gir** (herhangi bir sayfa açık olsun).
2. Sağ alt **⚖ Rücu Tara** → **🔭 Keşif (Dava)**.
3. Eklenti yargı-türü/birim kodlarını tarar (yalnız **birim listesi** çeker — dosya
   detayı/safahat DEĞİL → **harç çıkmaz**). "Tüketici" içeren birim listesini bulunca
   `yargiTuru / yargiBirimi / birimId` kodlarını ekranda gösterir.
4. `uyap-dava-kesif.json` İndirilenler'e düşer → **bu dosyayı bana gönder**, dava
   modunu (arama + evrak + PDF indirme) kesin kodlarla kurayım.

> Otomatik bulamazsa: Dosya Sorgulama'da yargı türünü **Hukuk → Tüketici Mahkemesi**
> seçip bir sorgu çalıştır, sonra tekrar 🔭 Keşif'e bas (pasif ağ-yakalama devreye girer).

## 3.6 ▶ Dava Sorgula (Tüketici Mahkemesi) · v0.4.0

Keşifle bulunan kesin kodlarla (`yargiTuru=1 · yargiBirimi=0912`) dava dosyalarını çeker.

1. **🎯 Dava Hedef** → her satıra `esas | Tüketici Mahkemesi` (ör. `2026/415 | İstanbul Anadolu 7. Tüketici Mahkemesi`). Mahkeme yazmazsan tüm Tüketici mahkemeleri taranır, **Ray taraf/davacı** olan seçilir.
2. **📥 Evrak PDF** modunu seç (önemli/tüm).
3. **▶ Dava Sorgula (Tüketici)** → durum + taraf + evrak; evrak `rucu-evrak\dava <no> <mahkeme>\` altına iner (hukuk PDF yolu denenip teyit edilir).

> İlk gerçek davada doğrula: arama dönüyor mu (`birimTuru2=0912`) ve PDF iniyor mu. İnmezse 🕸 Ağ ile gerçek PDF endpoint'i yakalanıp eklenir.

## 4. Sonra (faz 2 fikirleri)
- Eklenti formu kendi doldurup 6 sorguyu otomatik yapsın (tam otomasyon — denenebilir).
- Safahat/son işlem tarihi (haciz, tebligat) — ama bu dosya detayına girer, harçlı olabilir.
- "JSON İndir" yerine doğrudan Rücu Takip uygulamasına yazma.

## Notlar
- Bunlar senin vekili olduğun kendi dosyaların; liste sorgusu ücretsiz, detaya girmiyoruz.
- Resmi API değil; portal değişirse ufak selector bakımı gerekebilir (DOM Yakala ile çözeriz).
- Veri tarayıcından dışarı gitmez; JSON'u sen taşırsın.
