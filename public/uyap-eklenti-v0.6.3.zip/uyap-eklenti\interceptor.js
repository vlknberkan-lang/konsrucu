/* Rücu Takip — UYAP ağ-dinleyici (MAIN world)
 * Sayfanın KENDİ XHR/fetch trafiğini pasif dinler; ekstra istek ATMAZ.
 * Amaç: bilmediğimiz uçları (tebligat/barkod/teslim/evrak içerik) keşfetmek.
 * Yakaladığını window.postMessage ile izole content.js'e iletir.
 */
(function () {
  "use strict";
  if (window.__rucuIntercept) return;
  window.__rucuIntercept = true;

  function consider(url, method, reqBody, respText) {
    try {
      url = String(url || "");
      if (!/\.ajx|\.uyap/i.test(url)) return;
      const resp = String(respText || "");
      const blob = (url + " " + resp).toLowerCase();
      const hit = /barkod|posta|teslim|tebli|iade|gonderi|gönderi/i.test(blob);
      window.postMessage({
        source: "rucu-intercept",
        rec: {
          url: url,
          method: String(method || ""),
          req: String(reqBody || "").slice(0, 400),
          resp: resp.slice(0, 1500),
          hit: hit,
          t: Date.now()
        }
      }, "*");
    } catch (e) { /* yut */ }
  }

  const oOpen = XMLHttpRequest.prototype.open;
  const oSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__ru = u; this.__rm = m; return oOpen.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (b) {
    this.__rb = b;
    this.addEventListener("load", function () {
      try {
        if (this.responseType === "" || this.responseType === "text") consider(this.__ru, this.__rm, this.__rb, this.responseText);
      } catch (e) {}
    });
    return oSend.apply(this, arguments);
  };

  const oFetch = window.fetch;
  window.fetch = function () {
    const u = typeof arguments[0] === "string" ? arguments[0] : (arguments[0] && arguments[0].url) || "";
    const m = (arguments[1] && arguments[1].method) || "GET";
    const b = (arguments[1] && arguments[1].body) || "";
    return oFetch.apply(this, arguments).then((r) => {
      try { r.clone().text().then((t) => consider(u, m, b, t)).catch(() => {}); } catch (e) {}
      return r;
    });
  };

  console.log("[Rücu] ağ-dinleyici aktif (pasif)");
})();
